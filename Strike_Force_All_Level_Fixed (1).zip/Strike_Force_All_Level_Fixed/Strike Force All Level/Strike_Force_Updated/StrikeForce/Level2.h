#ifndef LEVEL2_H
#define LEVEL2_H

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include "gamesave.h"

// ============================================================
// LEVEL 2 - FROZEN FRONT
// ============================================================

// ------------------------------------------------------------
// External variables/functions coming from iMain.cpp
// ------------------------------------------------------------

extern int gameState;
extern int score;

// ============================================================
// LEVEL 2 CONSTANTS
// ============================================================

const int LEVEL2_WORLD_WIDTH = 6000;

const int LEVEL2_PLAYER_WIDTH = 100;
const int LEVEL2_PLAYER_HEIGHT = 100;

const int LEVEL2_ENEMY_WIDTH = 100;
const int LEVEL2_ENEMY_HEIGHT = 100;

const int LEVEL2_ENEMY_SLOTS = 20;
const int LEVEL2_WIN_KILLS = 20;
const int LEVEL2_MAX_ACTIVE_ENEMIES = 8;


// ============================================================
// LEVEL 2 IMAGE VARIABLES
// ============================================================

int winterBG;

int winterPlayerImg[5];
int snowEnemyImg[9];

int campfireImg;
int snowBearImg;


// ============================================================
// PLAYER VARIABLES
// ============================================================

int level2PlayerX = 100;
int level2PlayerY = 100;

int level2PlayerGroundY = 100;

int level2PlayerFrame = 0;

bool level2Jumping = false;
float level2PlayerVelocityY = 0;

bool level2WasUpKeyDown = false;

int level2JumpCount = 0;

clock_t level2LastUpPressTime = 0;


// ============================================================
// CAMERA
// ============================================================

float level2CameraX = 0;


// ============================================================
// PLAYER MOVEMENT
// ============================================================

int level2PlayerSpeed = 6;




// ============================================================
// TEMPERATURE SYSTEM
// ============================================================

int level2Temperature = 100;

clock_t level2LastTemperatureTime = 0;

bool level2NearCampfire = false;


// ============================================================
// SNOWSTORM
// ============================================================

bool level2SnowStorm = false;

clock_t level2SnowStormStartTime = 0;


// ============================================================
// SNOW PARTICLES
// ============================================================

struct Level2Snow
{
	int x;
	int y;
	int speed;
};

Level2Snow level2Snow[120];


// ============================================================
// ICE
// ============================================================

bool level2OnIce = false;


// ============================================================
// ENEMY STRUCTURE
// ============================================================

struct Level2Enemy
{
	int x;
	int y;

	int groundY;

	int speed;

	int frame;

	bool alive;

	bool jumping;

	float velocityY;

	// Special Snow Bear
	bool isSpecial;
};

Level2Enemy level2Enemies[LEVEL2_ENEMY_SLOTS];


// ============================================================
// COMBAT SYSTEM
// ============================================================

float level2PlayerLife = 120.0f;

float level2EnemyLife[LEVEL2_ENEMY_SLOTS];

bool level2PlayerAttacking = false;
bool level2WasSpaceKeyDown = false;

// How long the attack visual stays on screen
clock_t level2AttackStartTime = 0;

// Time of the last attack (used only for the attack animation timing)
clock_t level2LastAttackTime = 0;

// Attack animation lasts 0.25 seconds
const double LEVEL2_ATTACK_DURATION = 0.25;

// Melee attack range
const int LEVEL2_ATTACK_RANGE = 140;

// Player direction
// 1 = right
// -1 = left
int level2PlayerFacing = 1;

// Shows that an enemy was recently hit
bool level2EnemyHit[LEVEL2_ENEMY_SLOTS];
clock_t level2EnemyLastContactDamage[LEVEL2_ENEMY_SLOTS];
const double LEVEL2_ENEMY_CONTACT_DAMAGE_INTERVAL = 0.75;
const float LEVEL2_ENEMY_CONTACT_DAMAGE = 8.0f;

// Time when each enemy was hit
clock_t level2EnemyHitTime[LEVEL2_ENEMY_SLOTS];
int level2EnemiesDefeated = 0;

// Enemy spawn timing
clock_t level2LastEnemySpawnTime = 0;

// These are reusable enemy slots, NOT a total enemy limit.
// Enemies can be spawned again after an old slot is killed or recycled.
double level2EnemySpawnDelay = 3.0;
const double LEVEL2_ENEMY_SPAWN_MIN = 4.5;
const double LEVEL2_ENEMY_SPAWN_MAX = 7.2;
bool level2SpawnTimerStarted = false;

// Special Snow Bear: available after 7 Level 2 kills,
// and can appear at most 3 times during the level.
int level2SpecialEnemiesSpawned = 0;
const int LEVEL2_MAX_SPECIAL_ENEMIES = 3;
const float LEVEL2_SPECIAL_DAMAGE = 3.85f; // 10% more than 3.5


// ============================================================
// LEVEL 2 OBJECT POSITIONS
// ============================================================

// Ice section
int level2IceStart = 1900;
int level2IceWidth = 700;

// Campfire
int level2CampfireY = 100;
const int LEVEL2_MAX_CAMPFIRES_PER_CYCLE = 6;
int level2CampfireCount = 3;
int level2CampfireX[LEVEL2_MAX_CAMPFIRES_PER_CYCLE];
bool level2CampfireUsed[LEVEL2_MAX_CAMPFIRES_PER_CYCLE];
int level2CampfireCycle = -999999;
int level2ActiveCampfire = -1;
bool level2CampfireActive = false;
clock_t level2CampfireStartTime = 0;
clock_t level2LastCampfireHealTime = 0;

// Snowstorm begins here
int level2StormStart = 3800;


// ============================================================
// LOAD LEVEL 2 IMAGES
// ============================================================

void loadLevel2Images()
{
	// Backgrounds
	winterBG = iLoadImage("winterBG.png");
	
	// Winter player animation
	for (int i = 0; i < 5; i++)
	{
		char path[30];

		sprintf_s(path, "wp%d.png", i + 1);

		winterPlayerImg[i] = iLoadImage(path);
	}
	
	// Snow Beast animation: f0/f1 are walking frames; f2-f8 are attack frames.
	for (int i = 0; i < 9; i++)
	{
		char path[30];
		sprintf_s(path, "f%d.png", i);
		snowEnemyImg[i] = iLoadImage(path);
	}

	// Objects
	campfireImg = iLoadImage("campfire.png");
	snowBearImg = iLoadImage("w5.png");
	
}


// Forward declaration for the adaptive enemy spawn timer.
double getLevel2EnemySpawnDelay();

// ============================================================
// RESET LEVEL 2
// ============================================================

void resetLevel2()
{
	// Complete fresh-run reset. This function is used both when
	// entering Level 2 and when RETRY is pressed after WIN/LOSS.
	gameOverScreenActive = false;
	gameOverHandled = false;
	gameOverFinalScore = 0;
	gameOverLevelNumber = 2;
	currentRunElapsedSeconds = 0.0;

	level2PlayerX = 100;
	level2PlayerY = 100;

	level2PlayerGroundY = 100;

	level2PlayerFrame = 0;

	level2Jumping = false;

	level2PlayerVelocityY = 0;

	level2JumpCount = 0;

	level2WasUpKeyDown = false;

	level2CameraX = 0;
	
	level2PlayerAttacking = false;

	level2AttackStartTime = 0;

	// Allows the player to attack immediately after entering Level 2
	level2LastAttackTime = 0;
	level2WasSpaceKeyDown = false;

	level2PlayerFacing = 1;

	// BUGFIX: level2PlayerLife was only ever initialized once (at program
	// start) and was never restored here. That meant a RETRY after dying
	// (life == 0) left life at 0, so the very next frame's life-check
	// instantly re-triggered Game Over again - which looked like RETRY
	// was "resuming" the same lost run instead of starting a new one.
	level2PlayerLife = 120.0f;

	level2CampfireActive = false;
	level2CampfireStartTime = 0;
	level2LastCampfireHealTime = 0;
	level2ActiveCampfire = -1;
	level2CampfireCycle = -999999;
	for (int i = 0; i < LEVEL2_MAX_CAMPFIRES_PER_CYCLE; i++)
	{
		level2CampfireX[i] = 0;
		level2CampfireUsed[i] = false;
	}

	for (int i = 0; i < LEVEL2_ENEMY_SLOTS; i++)
	{
		level2EnemyLife[i] = 10.0f;

		level2EnemyHit[i] = false;
		level2EnemyHitTime[i] = 0;
		level2EnemyLastContactDamage[i] = 0;
	}
	

	level2Temperature = 100;

	level2NearCampfire = false;

	level2SnowStorm = false;

	level2OnIce = false;

	level2EnemiesDefeated = 0;
	score = 0;

	level2LastEnemySpawnTime = clock();
	level2EnemySpawnDelay = getLevel2EnemySpawnDelay();
	level2SpawnTimerStarted = true;
	level2SpecialEnemiesSpawned = 0;

	// --------------------------------------------------------
	// Initialize the reusable Snow Beast pool.
	// Only the first Beast is active initially.
	// Slots are reused forever, so spawning does not stop at 20 enemies.
	// --------------------------------------------------------

	for (int i = 0; i < LEVEL2_ENEMY_SLOTS; i++)
	{
		level2EnemyLife[i] = 10.0f;

		level2Enemies[i].x = 900 + i * 250;
		level2Enemies[i].y = 100;
		level2Enemies[i].groundY = 100;
		level2Enemies[i].speed = 3 + (i % 3);
		level2Enemies[i].frame = 0;

		// Only the first Beast starts alive.
		level2Enemies[i].alive = (i == 0);

		level2Enemies[i].jumping = false;
		level2Enemies[i].velocityY = 0;
		level2Enemies[i].isSpecial = false;

		level2EnemyHit[i] = false;
		level2EnemyHitTime[i] = 0;
		level2EnemyLastContactDamage[i] = 0;
	}
	// --------------------------------------------------------
	// Snow particles
	// --------------------------------------------------------

	for (int i = 0; i < 120; i++)
	{
		level2Snow[i].x = rand() % 800;
		level2Snow[i].y = rand() % 700;
		level2Snow[i].speed = 2 + rand() % 4;
	}


	level2LastTemperatureTime = clock();

	level2SnowStormStartTime = 0;

	resetGameOverState();
	startRunTimer();
}


// ============================================================
// DRAW LEVEL 2 BACKGROUND
// ============================================================

void drawLevel2Background()
{
	// winterBG.png is 2400x700, so tile it continuously.
	// This keeps the background visible even after the camera
	// passes the original 6000-pixel world.
	const int BG_WIDTH = 2400;

	int camera = (int)level2CameraX;
	int offset = camera % BG_WIDTH;

	iShowImage(-offset, 0, BG_WIDTH, 700, winterBG);
	iShowImage(BG_WIDTH - offset, 0, BG_WIDTH, 700, winterBG);
}


// ============================================================
// DRAW TEMPERATURE BAR
// ============================================================

void drawLevel2Temperature()
{
	char tempText[50];

	sprintf_s(tempText, "Temperature: %d", level2Temperature);

	iSetColor(255, 255, 255);

	iText(20,640,tempText,GLUT_BITMAP_HELVETICA_18);

	// Outer bar

	iSetColor(255, 255, 255);
	iRectangle(20,600,200,20);

	// Inner bar

	int barWidth = level2Temperature * 2;
    if (barWidth < 0)
	{
		barWidth = 0;
	}

	iSetColor(0, 200, 255);

	iFilledRectangle(20,600,barWidth,20);
}


// ============================================================
// DRAW OBJECTIVES
// ============================================================

void drawLevel2Objectives()
{
	char scoreText[50];

	sprintf_s(
		scoreText,
		"Score: %d / %d",
		level2EnemiesDefeated,
		LEVEL2_WIN_KILLS
		);

	iSetColor(255, 255, 255);

	iText(
		20,
		570,
		scoreText,
		GLUT_BITMAP_HELVETICA_18
		);
}


// ============================================================
// DRAW ICE AREA
// ============================================================

void drawLevel2Ice()
{
	// Repeat the ice section every 6000 world units.
	int camera = (int)level2CameraX;
	int cycle = camera / LEVEL2_WORLD_WIDTH;

	for (int c = cycle - 1; c <= cycle + 1; c++)
	{
		int worldX = level2IceStart + c * LEVEL2_WORLD_WIDTH;
		int screenX = worldX - camera;

		if (screenX > -level2IceWidth && screenX < 800)
		{
			// Draw the ice directly instead of using ice.png.
			// This also fixes the black area caused by the missing image.
			iSetColor(190, 225, 245);
			iFilledRectangle(screenX, 100, level2IceWidth, 80);

			iSetColor(230, 250, 255);
			iFilledRectangle(screenX, 175, level2IceWidth, 5);

			iSetColor(255, 255, 255);
			iText(screenX + 250, 190, "ICE AREA", GLUT_BITMAP_HELVETICA_18);
		}
	}
}


// ============================================================
// DRAW CAMPFIRE
// ============================================================

void setupLevel2Campfires(int cycle)
{
	if (cycle == level2CampfireCycle)
	{
		return;
	}

	// 4 to 6 campfires per repeating world cycle (slightly more
	// frequent than before). The number and positions are
	// randomized for each cycle.
	unsigned int seed = (unsigned int)(cycle * 1103515245 + 12345);

	level2CampfireCount = 4 + (seed % 3); // 4, 5, or 6

	// Spread campfires across the full 6000-unit cycle so the
	// player has regular chances to recover life and temperature.
	for (int i = 0; i < level2CampfireCount; i++)
	{
		seed = seed * 1103515245 + 12345;

		int baseX = 800 + (i * 5000) / (level2CampfireCount - 1);
		int jitter = (int)(seed % 301) - 150;

		level2CampfireX[i] = baseX + jitter;

		if (level2CampfireX[i] < 400)
		{
			level2CampfireX[i] = 400;
		}

		if (level2CampfireX[i] > LEVEL2_WORLD_WIDTH - 300)
		{
			level2CampfireX[i] = LEVEL2_WORLD_WIDTH - 300;
		}

		level2CampfireUsed[i] = false;
	}

	// Clear unused slots from the previous cycle.
	for (int i = level2CampfireCount; i < LEVEL2_MAX_CAMPFIRES_PER_CYCLE; i++)
	{
		level2CampfireX[i] = 0;
		level2CampfireUsed[i] = true;
	}

	level2CampfireCycle = cycle;
	level2ActiveCampfire = -1;
	level2CampfireActive = false;
}

void drawLevel2Campfire()
{
	int camera = (int)level2CameraX;
	int cycle = camera / LEVEL2_WORLD_WIDTH;

	setupLevel2Campfires(cycle);

	for (int c = cycle - 1; c <= cycle + 1; c++)
	{
		// Only generate positions for the currently visible cycle.
		if (c != cycle)
		{
			continue;
		}

		for (int i = 0; i < level2CampfireCount; i++)
		{
			int worldX = level2CampfireX[i] + c * LEVEL2_WORLD_WIDTH;
			int screenX = worldX - camera;

			if (screenX > -100 && screenX < 800 &&
				(!level2CampfireUsed[i] || level2ActiveCampfire == i))
			{
				// The campfire is visible so the player can see where it is.
				iShowImage(screenX, level2CampfireY, 100, 100, campfireImg);

				iSetColor(255, 220, 100);
				iText(screenX - 20, 220, "CAMPFIRE", GLUT_BITMAP_HELVETICA_18);
			}
		}
	}
}

// ============================================================
// DRAW SNOW
// ============================================================

void drawLevel2Snow()
{
	int snowCount = 50;

	if (level2SnowStorm)
	{
		snowCount = 120;
	}


	iSetColor(255, 255, 255);

	for (int i = 0; i < snowCount; i++)
	{
		iFilledCircle(
			level2Snow[i].x,
			level2Snow[i].y,
			2
			);
	}
}


// ============================================================
// DRAW SNOWSTORM DARK OVERLAY
// ============================================================

void drawLevel2StormEffect()
{
	if (level2SnowStorm)
	{
		iSetColor(180, 200, 220);

		iFilledRectangle(0,0,800,700);

		// Snow is drawn again on top
		drawLevel2Snow();
	}
}


// ============================================================
// DRAW LEVEL 2
// ============================================================

void drawLevel2()
{
	iClear();


	// Background
	drawLevel2Background();


	// Ice sections repeat with the background.
	drawLevel2Ice();


	// Campfire
	drawLevel2Campfire();


	// --------------------------------------------------------
	// Draw enemies
	// --------------------------------------------------------

	for (int i = 0; i < LEVEL2_ENEMY_SLOTS; i++)
	{
		if (level2Enemies[i].alive)
		{
			int screenX =
				level2Enemies[i].x -
				(int)level2CameraX;


			if (screenX > -100 && screenX < 800)
			{
				clock_t now = clock();

				double hitTime =
					(double)(now - level2EnemyHitTime[i]) / CLOCKS_PER_SEC;

				// Special Snow Bear uses w5.png. Regular enemies use
				// f0/f1 while walking and f2-f8 while attacking.
				int enemyImage = snowEnemyImg[level2Enemies[i].frame];
				if (level2Enemies[i].isSpecial)
				{
					enemyImage = snowBearImg;
				}

				if (level2EnemyHit[i] && hitTime < 0.2)
				{
					// Shake the actual enemy image. No white background.
					int shake = ((int)(hitTime * 1000) % 2 == 0) ? 8 : -8;

					iShowImage(screenX + shake,
						level2Enemies[i].y,
						LEVEL2_ENEMY_WIDTH,
						LEVEL2_ENEMY_HEIGHT,
						enemyImage);

					iSetColor(255, 50, 50);
					iText(screenX + 25,
						level2Enemies[i].y + 115,
						"HIT!",
						GLUT_BITMAP_HELVETICA_18);
				}
				else
				{
					level2EnemyHit[i] = false;

					iShowImage(screenX,
						level2Enemies[i].y,
						LEVEL2_ENEMY_WIDTH,
						LEVEL2_ENEMY_HEIGHT,
						enemyImage);
				}

				if (level2Enemies[i].isSpecial)
				{
					iSetColor(255, 220, 0);
					iText(screenX, level2Enemies[i].y + 130,
						"SNOW BEAR", GLUT_BITMAP_HELVETICA_12);
				}
				char beastLifeText[30];

				sprintf_s(beastLifeText,"HP: %.1f",	level2EnemyLife[i]
					);

				iSetColor(255, 50, 50);

				iText(screenX,level2Enemies[i].y + 105,
					beastLifeText,
					GLUT_BITMAP_HELVETICA_12
					);
			}
		}
	}


	// --------------------------------------------------------
	// Draw player
	// --------------------------------------------------------
	// wp1/wp2 = normal walking. wp3/wp4/wp5 = attack animation.
	int playerImageIndex = 0;
	if (level2PlayerAttacking)
	{
		playerImageIndex = 2 + ((level2PlayerFrame / 2) % 3);
	}
	else
	{
		playerImageIndex = level2PlayerFrame % 2;
	}

	iShowImage(level2PlayerX, level2PlayerY, 100, 100, winterPlayerImg[playerImageIndex]);
	// HUD boxes: temperature, life, score and run time.
	drawLevel2Temperature();

	// Life box
	iSetColor(30, 90, 120);
	iFilledRectangle(20, 505, 200, 38);
	iSetColor(255, 255, 255);
	char lifeText[50];
	sprintf_s(lifeText, "Life: %.1f / 120", level2PlayerLife);
	drawCenteredButtonText(20, 505, 200, 38, lifeText);

	// Score box
	iSetColor(25, 100, 155);
	iFilledRectangle(590, 620, 190, 50);
	iSetColor(255, 255, 255);
	char scoreBoxText[50];
	sprintf_s(scoreBoxText, "SCORE: %d", level2EnemiesDefeated);
	drawCenteredButtonText(590, 620, 190, 50, scoreBoxText);

	// Time bar - fills as the run continues, with the live time centered in it.
	double runTime = getCurrentRunTime();
	const double TIME_BAR_MAX_SECONDS = 300.0;
	int timeFill = (int)((runTime / TIME_BAR_MAX_SECONDS) * 190.0);
	if (timeFill > 190) timeFill = 190;
	if (timeFill < 0) timeFill = 0;
	iSetColor(25, 70, 110);
	iFilledRectangle(300, 620, 230, 50);
	iSetColor(100, 190, 235);
	iFilledRectangle(300, 620, timeFill, 50);
	iSetColor(255, 255, 255);
	char timeText[50];
	formatRunTime(runTime, timeText, sizeof(timeText));
	char timeLabel[70];
	sprintf_s(timeLabel, "TIME %s", timeText);
	drawCenteredButtonText(300, 620, 230, 50, timeLabel);

	// Objective progress stays centered in its own small HUD line.
	iSetColor(255, 255, 255);
	drawCenteredText(445, 575, "Defeat 20 Snow Beasts", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(430, 550, "Time & Score progress", GLUT_BITMAP_HELVETICA_12);

	// Snow
	drawLevel2Snow();


	// Storm overlay
	if (level2SnowStorm)
	{
		// Don't completely cover the screen.
		// Use a light transparent-looking visual effect
		// with snow particles instead.
		drawLevel2Snow();
	}

	if (gameOverScreenActive)
	{
		drawGameOverScreen(800, 700);
	}
}


// ============================================================
// PLAYER MOVEMENT
// ============================================================

void moveLevel2Player()
{
	// --------------------------------------------------------
	// Normal speed
	// --------------------------------------------------------

	level2PlayerSpeed = 6;


	// --------------------------------------------------------
	// Ice makes movement faster / slippery feeling
	// --------------------------------------------------------

	if (level2OnIce)
	{
		level2PlayerSpeed = 8;
	}


	// --------------------------------------------------------
	// Very low temperature slows player
	// --------------------------------------------------------

	if (level2Temperature <= 25)
	{
		level2PlayerSpeed = 3;
	}


	// --------------------------------------------------------
	// LEFT
	// --------------------------------------------------------

	if (
		isKeyPressed('a') ||
		isKeyPressed('A') ||
		isSpecialKeyPressed(GLUT_KEY_LEFT)
		)
	{
		level2PlayerX -= level2PlayerSpeed;
		level2PlayerFacing = -1;
		if (level2PlayerX < 0)
		{
			level2PlayerX = 0;
		}
	}


	// --------------------------------------------------------
	// RIGHT
	// --------------------------------------------------------

	if (
		isKeyPressed('d') ||
		isKeyPressed('D') ||
		isSpecialKeyPressed(GLUT_KEY_RIGHT)
		)
	{
		level2PlayerFacing = 1;

		// Keep about 1/3 of the screen (around 267 pixels)
		// visible in front of the player.
		const int PLAYER_SCREEN_LIMIT = 533; // 2/3 of 800

		if (level2PlayerX < PLAYER_SCREEN_LIMIT)
		{
			level2PlayerX += level2PlayerSpeed;
			if (level2PlayerX > PLAYER_SCREEN_LIMIT)
			{
				level2PlayerX = PLAYER_SCREEN_LIMIT;
			}
		}
		else
		{
			// Once the player reaches 2/3 of the frame,
			// move the camera at exactly the same speed.
			level2CameraX += level2PlayerSpeed;
		}
	}
}


// ============================================================
// LEVEL 2 JUMP
// ============================================================

void jumpLevel2Player()
{
	bool upPressed =
		isSpecialKeyPressed(GLUT_KEY_UP);


	if (upPressed && !level2WasUpKeyDown)
	{
		clock_t now = clock();


		double secondsSinceLastPress =
			(double)(now - level2LastUpPressTime)
			/ CLOCKS_PER_SEC;


		if (!level2Jumping)
		{
			level2Jumping = true;

			level2PlayerVelocityY = 20;

			level2JumpCount = 1;
		}
		else if (
			secondsSinceLastPress <= 0.35 &&
			level2JumpCount < 3
			)
		{
			level2PlayerVelocityY = 20;

			level2JumpCount++;
		}


		level2LastUpPressTime = now;
	}


	level2WasUpKeyDown = upPressed;


	// --------------------------------------------------------
	// Apply jump physics
	// --------------------------------------------------------

	if (level2Jumping)
	{
		level2PlayerY +=
			(int)level2PlayerVelocityY;


		level2PlayerVelocityY -= 1.5f;


		if (level2PlayerY > 500)
		{
			level2PlayerY = 500;

			if (level2PlayerVelocityY > 0)
			{
				level2PlayerVelocityY = 0;
			}
		}


		if (level2PlayerY <= level2PlayerGroundY)
		{
			level2PlayerY =
				level2PlayerGroundY;


			level2Jumping = false;

			level2PlayerVelocityY = 0;

			level2JumpCount = 0;
		}
	}
}



// ============================================================
// ENEMY MOVEMENT
// ============================================================

double getLevel2EnemySpawnDelay()
{
	int playerWorldX = (int)level2CameraX + level2PlayerX;
	int cycleX = playerWorldX % LEVEL2_WORLD_WIDTH;

	if (cycleX < 0)
	{
		cycleX += LEVEL2_WORLD_WIDTH;
	}

	// Enemy flow is intentionally slower so the player's life,
	// temperature, and campfire healing stay more balanced.
	// This reduces the average enemy arrival rate by roughly 40-50%.
	if (cycleX < level2StormStart)
	{
		return 4.5 + (rand() % 4) * 0.9; // 4.5, 5.4, 6.3, 7.2
	}

	return 3.2 + (rand() % 4) * 0.8; // 3.2, 4.0, 4.8, 5.6
}

int countActiveLevel2Enemies()
{
	int count = 0;

	for (int i = 0; i < LEVEL2_ENEMY_SLOTS; i++)
	{
		if (level2Enemies[i].alive)
		{
			count++;
		}
	}

	return count;
}

int findFreeLevel2EnemySlot()
{
	for (int i = 0; i < LEVEL2_ENEMY_SLOTS; i++)
	{
		if (!level2Enemies[i].alive)
		{
			return i;
		}
	}

	return -1;
}

void spawnLevel2Enemies()
{
	clock_t now = clock();

	if (!level2SpawnTimerStarted)
	{
		level2SpawnTimerStarted = true;
		level2LastEnemySpawnTime = now;
		level2EnemySpawnDelay = getLevel2EnemySpawnDelay();
	}

	double secondsSinceLastSpawn =
		(double)(now - level2LastEnemySpawnTime) / CLOCKS_PER_SEC;

	if (secondsSinceLastSpawn < level2EnemySpawnDelay)
	{
		return;
	}

	// Only limit the number visible at one time. This does NOT limit
	// the total number of enemies that can appear during the level.
	if (countActiveLevel2Enemies() >= LEVEL2_MAX_ACTIVE_ENEMIES)
	{
		return;
	}

	int i = findFreeLevel2EnemySlot();
	if (i == -1)
	{
		return;
	}

	// Spawn just outside the right edge of the current frame.
	int spawnX = (int)level2CameraX + 820;

	// Keep a reasonable gap from another enemy near the entry point.
	for (int tries = 0; tries < 5; tries++)
	{
		bool tooClose = false;

		for (int j = 0; j < LEVEL2_ENEMY_SLOTS; j++)
		{
			if (!level2Enemies[j].alive)
			{
				continue;
			}

			int distance = level2Enemies[j].x - spawnX;
			if (distance < 0)
			{
				distance = -distance;
			}

			if (distance < 180)
			{
				tooClose = true;
				break;
			}
		}

		if (!tooClose)
		{
			break;
		}

		spawnX += 120;
	}

	level2Enemies[i].alive = true;
	level2EnemyLife[i] = 10.0f;
	level2Enemies[i].x = spawnX;
	level2Enemies[i].y = 100;
	level2Enemies[i].groundY = 100;
	level2Enemies[i].speed = 3 + (rand() % 3);
	level2Enemies[i].frame = rand() % 5;
	level2Enemies[i].jumping = false;
	level2Enemies[i].velocityY = 0;

	// Special Snow Bear: starts after 7 kills, random chance, max 3.
	level2Enemies[i].isSpecial = false;
	if (level2EnemiesDefeated >= 7 &&
		level2SpecialEnemiesSpawned < LEVEL2_MAX_SPECIAL_ENEMIES)
	{
		if (rand() % 100 < 25)
		{
			level2Enemies[i].isSpecial = true;
			level2SpecialEnemiesSpawned++;
		}
	}

	level2EnemyHit[i] = false;
	level2EnemyHitTime[i] = 0;

	// Start a fresh timer for the next enemy.
	level2LastEnemySpawnTime = now;
	level2EnemySpawnDelay = getLevel2EnemySpawnDelay();
}

void updateLevel2Enemies()
{
	for (int i = 0; i < LEVEL2_ENEMY_SLOTS; i++)
	{
		if (!level2Enemies[i].alive)
		{
			continue;
		}


		// Move toward player

		int playerWorldX =
			(int)level2CameraX + level2PlayerX;

		int distance =
			level2Enemies[i].x - playerWorldX;

		// Recycle a Beast that is far behind the player.
		// This keeps the enemy flow continuous while the world loops.
		if (distance < -900)
		{
			level2Enemies[i].alive = false;
			continue;
		}

		// --------------------------------------------------------
		// Move toward player only when far enough away
		// --------------------------------------------------------

		if (distance > 120)
		{
			level2Enemies[i].x -= level2Enemies[i].speed;
		}
		else if (distance < -120)
		{
			level2Enemies[i].x += level2Enemies[i].speed;
		}

		// If within 120 pixels, stop moving.
		// This creates a proper fighting distance.

		// Animation: f0/f1 while walking; f2-f8 while touching the player.
		int playerWorldXForAnimation = (int)level2CameraX + level2PlayerX;
		int contactDistance = level2Enemies[i].x - playerWorldXForAnimation;
		if (contactDistance < 0) contactDistance = -contactDistance;
		bool enemyAttacking = (contactDistance < 105 &&
			level2Enemies[i].y < level2PlayerY + 90 && level2Enemies[i].y + 90 > level2PlayerY);

		level2Enemies[i].frame++;
		if (enemyAttacking)
		{
			if (level2Enemies[i].frame < 2 || level2Enemies[i].frame > 8)
				level2Enemies[i].frame = 2;
		}
		else
		{
			level2Enemies[i].frame %= 2;
		}


		// Random jump

		if (
			!level2Enemies[i].jumping &&
			rand() % 100 < 2
			)
		{
			level2Enemies[i].jumping = true;

			level2Enemies[i].velocityY = 15;
		}


		if (level2Enemies[i].jumping)
		{
			level2Enemies[i].y +=
				(int)level2Enemies[i].velocityY;


			level2Enemies[i].velocityY -= 1.5f;


			if (
				level2Enemies[i].y <=
				level2Enemies[i].groundY
				)
			{
				level2Enemies[i].y =
					level2Enemies[i].groundY;

				level2Enemies[i].jumping = false;

				level2Enemies[i].velocityY = 0;
			}
		}
	}
}

void attackLevel2()
{
	clock_t now = clock();

	// Turn off the attack visual after 0.25 seconds.
	if (level2PlayerAttacking)
	{
		double attackTime =
			(double)(now - level2AttackStartTime) / CLOCKS_PER_SEC;

		if (attackTime >= LEVEL2_ATTACK_DURATION)
		{
			level2PlayerAttacking = false;
		}
	}

	// Spacebar must be freshly pressed.
	// There is NO 1-second attack cooldown anymore.
	bool spaceDown = isKeyPressed(' ');

	if (spaceDown && !level2WasSpaceKeyDown)
	{
		level2AttackStartTime = now;
		level2LastAttackTime = now;
		level2PlayerAttacking = true;

		int targetEnemy = -1;
		int closestDistance = 100000;

		int playerWorldX =
			(int)level2CameraX + level2PlayerX;

		for (int i = 0; i < LEVEL2_ENEMY_SLOTS; i++)
		{
			if (!level2Enemies[i].alive)
			{
				continue;
			}

			int distance = level2Enemies[i].x - playerWorldX;

			if (level2PlayerFacing == 1)
			{
				if (distance < 0)
				{
					continue;
				}
			}
			else
			{
				if (distance > 0)
				{
					continue;
				}

				distance = -distance;
			}

			if (distance <= LEVEL2_ATTACK_RANGE && distance < closestDistance)
			{
				closestDistance = distance;
				targetEnemy = i;
			}
		}

		if (targetEnemy != -1)
		{
			// Regular Beast: 3.5 damage.
			// Special Snow Bear: 10% more = 3.85 damage.
			float damage = 3.5f;
			if (level2Enemies[targetEnemy].isSpecial)
			{
				damage = LEVEL2_SPECIAL_DAMAGE;
			}

			// Player attacks the beast; enemy contact damage is handled
			// independently below, so enemies can attack even if the player
			// never presses Space.
			level2EnemyLife[targetEnemy] -= 3.5f;

			// Beast hit reaction.
			level2EnemyHit[targetEnemy] = true;
			level2EnemyHitTime[targetEnemy] = now;

			// Knock the Beast backward.
			if (level2PlayerFacing == 1)
			{
				level2Enemies[targetEnemy].x += 40;
			}
			else
			{
				level2Enemies[targetEnemy].x -= 40;
			}

			if (level2EnemyLife[targetEnemy] <= 0)
			{
				level2EnemyLife[targetEnemy] = 0;
				level2Enemies[targetEnemy].alive = false;
				level2EnemiesDefeated++;
				score++;

				if (level2EnemiesDefeated >= LEVEL2_WIN_KILLS)
				{
					triggerGameOver(GAMEOVER_LEVEL_COMPLETE, score, 2);
					unlockLevel(3); // clearing Level 2 unlocks Level 3
					level2WasSpaceKeyDown = spaceDown;
					return;
				}
			}

			if (level2PlayerLife <= 0)
			{
				level2PlayerLife = 0;
				triggerGameOver(GAMEOVER_PLAYER_DIED, score, 2);
			}
		}
	}

	level2WasSpaceKeyDown = spaceDown;
}


// ============================================================
// PLAYER VS ENEMY COMBAT
// ============================================================
void checkLevel2EnemyCollision()
{
	clock_t now = clock();
	int playerWorldX = (int)level2CameraX + level2PlayerX;

	for (int i = 0; i < LEVEL2_ENEMY_SLOTS; i++)
	{
		if (!level2Enemies[i].alive) continue;

		bool touching = checkCollision(
			level2PlayerX, level2PlayerY, LEVEL2_PLAYER_WIDTH, LEVEL2_PLAYER_HEIGHT,
			level2Enemies[i].x - (int)level2CameraX, level2Enemies[i].y,
			LEVEL2_ENEMY_WIDTH, LEVEL2_ENEMY_HEIGHT);

		if (touching)
		{
			double sinceLast = (double)(now - level2EnemyLastContactDamage[i]) / CLOCKS_PER_SEC;
			if (level2EnemyLastContactDamage[i] == 0 || sinceLast >= LEVEL2_ENEMY_CONTACT_DAMAGE_INTERVAL)
			{
				float damage = level2Enemies[i].isSpecial ? LEVEL2_SPECIAL_DAMAGE * 2.0f : LEVEL2_ENEMY_CONTACT_DAMAGE;
				level2PlayerLife -= damage;
				level2EnemyLastContactDamage[i] = now;
			}
		}
	}

	if (level2PlayerLife <= 0)
	{
		level2PlayerLife = 0;
		triggerGameOver(GAMEOVER_PLAYER_DIED, score, 2);
	}
}

// ============================================================
// ICE CHECK
// ============================================================

void checkLevel2Ice()
{
	int playerWorldX =
		(int)level2CameraX +
		level2PlayerX;

	// The world repeats every LEVEL2_WORLD_WIDTH pixels.
	// Check the player's position inside the current cycle so the
	// ice area works again every time the background loops.
	int cycleX = playerWorldX % LEVEL2_WORLD_WIDTH;

	if (cycleX < 0)
	{
		cycleX += LEVEL2_WORLD_WIDTH;
	}

	if (
		cycleX >= level2IceStart &&
		cycleX <= level2IceStart + level2IceWidth
		)
	{
		level2OnIce = true;
	}
	else
	{
		level2OnIce = false;
	}
}

// ============================================================
// CAMPFIRE / TEMPERATURE / LIFE
// ============================================================

void updateLevel2Temperature()
{
	int playerWorldX =
		(int)level2CameraX + level2PlayerX;

	clock_t now = clock();

	// --------------------------------------------------------
	// Prepare the campfires for the current repeating cycle.
	// --------------------------------------------------------

	int currentCycle = playerWorldX / LEVEL2_WORLD_WIDTH;
	int cycleX = playerWorldX % LEVEL2_WORLD_WIDTH;

	if (cycleX < 0)
	{
		cycleX += LEVEL2_WORLD_WIDTH;
		currentCycle--;
	}

	setupLevel2Campfires(currentCycle);

	// --------------------------------------------------------
	// Find a nearby unused campfire.
	// Campfires are more common in the snowstorm area.
	// --------------------------------------------------------

	// --------------------------------------------------------
	// Find a nearby unused campfire that is still ahead of the
	// player (not one they've already walked past), so it always
	// appears in front rather than behind.
	// --------------------------------------------------------

	if (!level2CampfireActive)
	{
		for (int i = 0; i < level2CampfireCount; i++)
		{
			if (level2CampfireUsed[i])
			{
				continue;
			}

			// Only trigger campfires that are still ahead of the player
			// (positive distance = campfire is further along the level).
			int distanceAhead = level2CampfireX[i] - cycleX;

			if (distanceAhead >= 0 && distanceAhead <= 180)
			{
				level2CampfireActive = true;
				level2ActiveCampfire = i;
				level2CampfireUsed[i] = true;
				level2CampfireStartTime = now;
				level2LastCampfireHealTime = now;
				break;
			}
		}
	}

	// --------------------------------------------------------
	// Campfire healing
	// --------------------------------------------------------

	if (level2CampfireActive)
	{
		double campfireTime =
			(double)(now - level2CampfireStartTime) / CLOCKS_PER_SEC;

		double healTime =
			(double)(now - level2LastCampfireHealTime) / CLOCKS_PER_SEC;

		if (healTime >= 1.0)
		{
			level2LastCampfireHealTime = now;

			// Temperature +10 (10% of maximum 100)
			level2Temperature += 10;

			// Life +9.6 (8% of maximum 120)
			level2PlayerLife += 9.6f;

			if (level2Temperature > 100)
			{
				level2Temperature = 100;
			}

			if (level2PlayerLife > 120)
			{
				level2PlayerLife = 120;
			}
		}

		// Campfire remains active for 3 seconds.
		if (campfireTime >= 3.0)
		{
			level2CampfireActive = false;
			level2ActiveCampfire = -1;
		}
	}

	// --------------------------------------------------------
	// Temperature decreases over time.
	// Rebalanced to be more forgiving: normal cooling now takes
	// 2 seconds per point lost (was 1s), and snowstorm cooling
	// takes 1 second per point (was losing 2 points every 1s).
	// --------------------------------------------------------

	double temperatureTime =
		(double)(now - level2LastTemperatureTime) / CLOCKS_PER_SEC;

	// Normal snow is slowest, ice is faster, snowstorm is fastest.
	double level2TemperatureTickInterval;
	if (level2SnowStorm)
		level2TemperatureTickInterval = 0.8;
	else if (level2OnIce)
		level2TemperatureTickInterval = 1.3;
	else
		level2TemperatureTickInterval = 2.0;

	if (temperatureTime >= level2TemperatureTickInterval)
	{
		level2LastTemperatureTime = now;

		level2Temperature--;

		if (level2Temperature < 0)
		{
			level2Temperature = 0;
		}
	}

	// Temperature reaching zero is a real death condition. It is never
	// automatically refilled or used as an emergency checkpoint.
	if (level2Temperature <= 0)
	{
		level2Temperature = 0;
		level2PlayerLife = 0;
		triggerGameOver(GAMEOVER_PLAYER_DIED, score, 2);
		return;
	}

	// --------------------------------------------------------
	// Player life reaching zero still ends the game.
	// --------------------------------------------------------

	if (level2PlayerLife <= 0)
	{
		level2PlayerLife = 0;
		triggerGameOver(GAMEOVER_PLAYER_DIED, score, 2);
	}
}

// ============================================================
// SNOW UPDATE
// ============================================================

void updateLevel2Snow()
{
	int snowSpeedMultiplier = 1;


	if (level2SnowStorm)
	{
		snowSpeedMultiplier = 2;
	}


	for (int i = 0; i < 120; i++)
	{
		level2Snow[i].y -=
			level2Snow[i].speed *
			snowSpeedMultiplier;


		level2Snow[i].x -= 1;


		if (
			level2Snow[i].y < 0 ||
			level2Snow[i].x < 0
			)
		{
			level2Snow[i].x =
				rand() % 800;

			level2Snow[i].y = 700;

			level2Snow[i].speed =
				2 + rand() % 4;
		}
	}
}


// ============================================================
// SNOWSTORM CHECK
// ============================================================

void checkLevel2Snowstorm()
{
	int playerWorldX =
		(int)level2CameraX + level2PlayerX;

	// Repeat the environment every 6000 pixels.
	int cycleX = playerWorldX % LEVEL2_WORLD_WIDTH;

	if (cycleX < 0)
	{
		cycleX += LEVEL2_WORLD_WIDTH;
	}

	// Storm exists only in the storm section of each cycle.
	level2SnowStorm = (cycleX >= level2StormStart);
}


// ============================================================
// PLAYER ANIMATION
// ============================================================

void updateLevel2PlayerAnimation()
{
	level2PlayerFrame++;

	if (level2PlayerFrame >= 5)
	{
		level2PlayerFrame = 0;
	}
}


// ============================================================
// MAIN LEVEL 2 UPDATE FUNCTION
// ============================================================

void updateLevel2()
{
	if (gameState != 1)
	{
		return;
	}

	// Freeze all gameplay while the Game Over / Win overlay is
	// showing, so the player can't keep moving/attacking underneath it.
	if (gameOverScreenActive)
	{
		return;
	}

	// --------------------------------------------------------
	// Player movement
	// --------------------------------------------------------

	moveLevel2Player();

	// --------------------------------------------------------
	// Player jumping
	// --------------------------------------------------------

	jumpLevel2Player();

	// --------------------------------------------------------
	// Player attack
	// --------------------------------------------------------

	attackLevel2();

	// --------------------------------------------------------
	// Enemy spawning
	// --------------------------------------------------------

	spawnLevel2Enemies();

	// --------------------------------------------------------
	// Enemy movement
	// --------------------------------------------------------

	updateLevel2Enemies();

	// --------------------------------------------------------
	// Enemy collision
	// --------------------------------------------------------

	checkLevel2EnemyCollision();

	// --------------------------------------------------------
	// Environment state first, so temperature uses the correct rate.
	// --------------------------------------------------------

	checkLevel2Ice();
	checkLevel2Snowstorm();

	// --------------------------------------------------------
	// Temperature + Campfire + Life
	// --------------------------------------------------------

	updateLevel2Temperature();

	// --------------------------------------------------------
	// Snow
	// --------------------------------------------------------

	updateLevel2Snow();

	// --------------------------------------------------------
	// Player animation
	// --------------------------------------------------------

	updateLevel2PlayerAnimation();
}
#endif