#ifndef MENU_H
#define MENU_H

#include <stdio.h>

extern int bg1; // Referencing the loaded background from main
extern int highestLevelUnlocked; // from gamesave.h
extern int highScoreByLevel[];   // from gamesave.h
extern int lastScoreByLevel[];   // from gamesave.h
extern const int GAMESAVE_LEVEL_COUNT; // from gamesave.h

// Draws a single line of text horizontally centered around
// centerX, at the given baseline Y, using the text's true pixel
// width (glutBitmapWidth) rather than a guessed offset.
void drawCenteredText(int centerX, int y, char* text, void* font)
{
	int textWidth = 0;
	for (char* c = text; *c != '\0'; c++)
	{
		textWidth += glutBitmapWidth(font, *c);
	}

	iText(centerX - textWidth / 2, y, text, font);
}

// Draws text horizontally AND vertically centered inside a
// button rectangle. Horizontal centering uses the text's true
// pixel width (glutBitmapWidth). Vertical centering places the
// baseline so the font's visual cap-height sits in the middle
// of the button, using GLUT_BITMAP_HELVETICA_18's ~12px cap
// height (half of that offsets the baseline below dead-center).
void drawCenteredButtonText(int btnX, int btnY, int btnW, int btnH, char* text)
{
	const int HELVETICA_18_CAP_HEIGHT = 12;

	int textWidth = 0;
	for (char* c = text; *c != '\0'; c++)
	{
		textWidth += glutBitmapWidth(GLUT_BITMAP_HELVETICA_18, *c);
	}

	int textX = btnX + (btnW - textWidth) / 2;
	int textY = btnY + (btnH - HELVETICA_18_CAP_HEIGHT) / 2;

	iText(textX, textY, text, GLUT_BITMAP_HELVETICA_18);
}

// Narrower buttons, shifted lower, so the stack clears the
// "Strike Force" logo art with room to spare, and EXIT now
// sits in the same stack (same size as the rest) below ABOUT
// instead of a separate corner button.
const int MENU_BTN_X = 330;
const int MENU_BTN_W = 140;
const int MENU_BTN_H = 42;
const int MENU_BTN_GAP = 14; // vertical gap between stacked buttons

const int MENU_START_BTN_Y = 360;
const int MENU_INSTRUCTIONS_BTN_Y = MENU_START_BTN_Y - (MENU_BTN_H + MENU_BTN_GAP);
const int MENU_HIGHSCORE_BTN_Y = MENU_INSTRUCTIONS_BTN_Y - (MENU_BTN_H + MENU_BTN_GAP);
const int MENU_STORY_BTN_Y = MENU_HIGHSCORE_BTN_Y - (MENU_BTN_H + MENU_BTN_GAP);
const int MENU_ABOUT_BTN_Y = MENU_STORY_BTN_Y - (MENU_BTN_H + MENU_BTN_GAP);
const int MENU_EXIT_BTN_Y = MENU_ABOUT_BTN_Y - (MENU_BTN_H + MENU_BTN_GAP);

void drawMenu() {
	// Draw the menu background (already includes the "Strike Force" logo art)
	iShowImage(0, 0, 800, 700, bg1);

	// Draw Start Button
	iSetColor(200, 0, 0);
	iFilledRectangle(MENU_BTN_X, MENU_START_BTN_Y, MENU_BTN_W, MENU_BTN_H);
	iSetColor(255, 255, 255);
	drawCenteredButtonText(MENU_BTN_X, MENU_START_BTN_Y, MENU_BTN_W, MENU_BTN_H, "START");

	// Draw Instructions Button
	iSetColor(0, 100, 200);
	iFilledRectangle(MENU_BTN_X, MENU_INSTRUCTIONS_BTN_Y, MENU_BTN_W, MENU_BTN_H);
	iSetColor(255, 255, 255);
	drawCenteredButtonText(MENU_BTN_X, MENU_INSTRUCTIONS_BTN_Y, MENU_BTN_W, MENU_BTN_H, "Instructions");

	// Draw High Score Button
	iSetColor(200, 160, 0);
	iFilledRectangle(MENU_BTN_X, MENU_HIGHSCORE_BTN_Y, MENU_BTN_W, MENU_BTN_H);
	iSetColor(255, 255, 255);
	drawCenteredButtonText(MENU_BTN_X, MENU_HIGHSCORE_BTN_Y, MENU_BTN_W, MENU_BTN_H, "HIGH SCORE");

	// Draw Description Button
	iSetColor(100, 60, 160);
	iFilledRectangle(MENU_BTN_X, MENU_STORY_BTN_Y, MENU_BTN_W, MENU_BTN_H);
	iSetColor(255, 255, 255);
	drawCenteredButtonText(MENU_BTN_X, MENU_STORY_BTN_Y, MENU_BTN_W, MENU_BTN_H, "DESCRIPTION");

	// Draw About Button
	iSetColor(60, 130, 120);
	iFilledRectangle(MENU_BTN_X, MENU_ABOUT_BTN_Y, MENU_BTN_W, MENU_BTN_H);
	iSetColor(255, 255, 255);
	drawCenteredButtonText(MENU_BTN_X, MENU_ABOUT_BTN_Y, MENU_BTN_W, MENU_BTN_H, "ABOUT");

	// Draw Exit Button (now part of the stack, same size, closes the application)
	iSetColor(150, 0, 0);
	iFilledRectangle(MENU_BTN_X, MENU_EXIT_BTN_Y, MENU_BTN_W, MENU_BTN_H);
	iSetColor(255, 255, 255);
	drawCenteredButtonText(MENU_BTN_X, MENU_EXIT_BTN_Y, MENU_BTN_W, MENU_BTN_H, "EXIT");
}

void drawDescriptionScreen()
{
	iSetColor(15, 15, 25);
	iFilledRectangle(0, 0, 800, 700);

	iSetColor(255, 220, 0);
	drawCenteredText(425, 600, "DESCRIPTION", GLUT_BITMAP_TIMES_ROMAN_24);

	iSetColor(255, 255, 255);
	drawCenteredText(480, 520, "Strike Force is a 2D action game where the player takes", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(480, 490, "control of the main character, Agent Zero. Each level is", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(480, 460, "filled with challenging enemies. The player must defeat", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(470, 430, "all foes to clear the area and complete the mission.", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(465, 380, "As the game progresses, the difficulty ramps up with", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(460, 350, "stronger enemies, forcing Agent Zero to rely on", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(460, 320, "strategic combat to survive the onslaught.", GLUT_BITMAP_HELVETICA_18);

	// Back Button (centered on the same axis)
	iSetColor(200, 0, 0);
	iFilledRectangle(350, 150, 100, 50);
	iSetColor(255, 255, 255);
	drawCenteredButtonText(350, 150, 100, 50, "BACK");
}

void drawAboutScreen()
{
	iSetColor(15, 25, 20);
	iFilledRectangle(0, 0, 800, 700);

	iSetColor(255, 220, 0);
	drawCenteredText(420, 610, "ABOUT", GLUT_BITMAP_TIMES_ROMAN_24);

	iSetColor(255, 255, 255);
	drawCenteredText(470, 540, "Strike Force is a 3-level action game built with", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(460, 510, "C++ and OpenGL (iGraphics / GLUT).", GLUT_BITMAP_HELVETICA_18);

	drawCenteredText(450, 460, "Level 1: Run-and-gun jungle shooter", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(455, 430, "Level 2: Side-scrolling survival brawler", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(450, 400, "Level 3: Aerial dogfight shoot-em-up", GLUT_BITMAP_HELVETICA_18);

	iSetColor(255, 220, 0);
	drawCenteredText(430, 340, "DEVELOPED BY", GLUT_BITMAP_HELVETICA_18);

	iSetColor(255, 255, 255);
	drawCenteredText(440, 305, "Atique Mahmud Shuvo", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(430, 275, "Md Tafsir Rahman", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(440, 245, "Mufakkharul Islam Rafi", GLUT_BITMAP_HELVETICA_18);

	// Back Button (centered on the same axis)
	iSetColor(200, 0, 0);
	iFilledRectangle(350, 150, 100, 50);
	iSetColor(255, 255, 255);
	drawCenteredButtonText(350, 150, 100, 50, "BACK");
}

void drawHighScoreScreen()
{
	iSetColor(20, 20, 30);
	iFilledRectangle(0, 0, 800, 700);

	iSetColor(255, 220, 0);
	drawCenteredText(435, 645, "HIGH SCORES", GLUT_BITMAP_TIMES_ROMAN_24);
	iSetColor(180, 180, 180);
	drawCenteredText(455, 615, "BEST: completed levels only | Time first, then score", GLUT_BITMAP_HELVETICA_12);
	drawCenteredText(460, 595, "LAST: latest two runs, whether completed or not | No ranking", GLUT_BITMAP_HELVETICA_12);

	const int levelColumnX[3] = { 145, 400, 655 };
	for (int level = 0; level < GAMESAVE_LEVEL_COUNT; level++)
	{
		int cx = levelColumnX[level];
		int panelX = cx - 115;

		// One panel per level, with two clearly separated sections.
		iSetColor(40, 70, 100);
		iFilledRectangle(panelX, 150, 230, 410);

		iSetColor(255, 255, 255);
		char levelTitle[20];
		sprintf_s(levelTitle, "LEVEL %d", level + 1);
		drawCenteredText(cx, 535, levelTitle, GLUT_BITMAP_HELVETICA_18);

		// BEST section - ranked, 3 entries.
		iSetColor(50, 100, 140);
		iFilledRectangle(panelX + 10, 325, 210, 195);
		iSetColor(255, 220, 0);
		drawCenteredText(cx, 495, "BEST SCORES", GLUT_BITMAP_HELVETICA_18);
		iSetColor(190, 190, 190);
		drawCenteredText(cx - 70, 465, "RANK", GLUT_BITMAP_HELVETICA_12);
		drawCenteredText(cx, 465, "TIME", GLUT_BITMAP_HELVETICA_12);
		drawCenteredText(cx + 70, 465, "SCORE", GLUT_BITMAP_HELVETICA_12);

		for (int rank = 0; rank < BEST_SCORE_COUNT; rank++)
		{
			int y = 435 - rank * 32;
			char rankText[12], timeText[20], scoreText[20];
			sprintf_s(rankText, "%d", rank + 1);
			formatRunTime(bestTimes[level][rank], timeText, sizeof(timeText));
			sprintf_s(scoreText, "%d", bestScores[level][rank]);
			iSetColor(255, 255, 255);
			drawCenteredText(cx - 70, y, rankText, GLUT_BITMAP_HELVETICA_12);
			drawCenteredText(cx, y, timeText, GLUT_BITMAP_HELVETICA_12);
			drawCenteredText(cx + 70, y, scoreText, GLUT_BITMAP_HELVETICA_12);
		}

		// LAST section - exactly two newest runs, no ranking.
		iSetColor(55, 75, 90);
		iFilledRectangle(panelX + 10, 165, 210, 145);
		iSetColor(255, 220, 0);
		drawCenteredText(cx, 285, "LAST 2 RUNS", GLUT_BITMAP_HELVETICA_18);
		iSetColor(190, 190, 190);
		drawCenteredText(cx - 40, 255, "TIME", GLUT_BITMAP_HELVETICA_12);
		drawCenteredText(cx + 45, 255, "SCORE", GLUT_BITMAP_HELVETICA_12);

		for (int r = 0; r < LAST_RUN_COUNT; r++)
		{
			int y = 225 - r * 30;
			char timeText[20], scoreText[20];
			formatRunTime(lastTimes[level][r], timeText, sizeof(timeText));
			sprintf_s(scoreText, "%d", lastScores[level][r]);
			iSetColor(255, 255, 255);
			drawCenteredText(cx - 40, y, timeText, GLUT_BITMAP_HELVETICA_12);
			drawCenteredText(cx + 45, y, scoreText, GLUT_BITMAP_HELVETICA_12);
		}
	}

	iSetColor(200, 0, 0);
	iFilledRectangle(350, 70, 100, 50);
	iSetColor(255, 255, 255);
	drawCenteredButtonText(350, 70, 100, 50, "BACK");
}

void drawInstructions() {
	iSetColor(30, 30, 30);
	iFilledRectangle(0, 0, 800, 700);

	iSetColor(255, 255, 255);
	drawCenteredText(440, 600, "LEVEL 1 / LEVEL 2 / level 3", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(450, 570, "Press Right Key to move Forward", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(450, 540, "Press Left Key to move Backward", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(430, 510, "Press Up Key to Jump", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(450, 480, "Press Space Key to Shoot / Attack", GLUT_BITMAP_HELVETICA_18);
	
	/*
	iSetColor(180, 220, 255);
	drawCenteredText(400, 430, "LEVEL 3", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(400, 400, "Press W / Up to fly higher", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(400, 370, "Press S / Down to dive lower", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(400, 340, "Press Space to fire", GLUT_BITMAP_HELVETICA_18);
	*/
	iSetColor(255, 220, 0);
	drawCenteredText(470, 290, "* Watch your health bar - touching an enemy deals damage", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(470, 260, "* Level 1: collect 10 apples AND defeat 10 enemies to win", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(460, 230, "* Level 2: defeat 20 snow beasts to win", GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(470, 200, "* Level 3: collect 20 coins AND defeat 15 enemies to win", GLUT_BITMAP_HELVETICA_18);

	iSetColor(200, 0, 0);
	iFilledRectangle(350, 130, 100, 50);
	iSetColor(255, 255, 255);
	drawCenteredButtonText(350, 130, 100, 50, "BACK");
}

void drawLevelSelection()
{
	iSetColor(20, 30, 50);
	iFilledRectangle(0, 0, 800, 700);

	iSetColor(255, 255, 255);
	drawCenteredText(435, 545, "SELECT LEVEL", GLUT_BITMAP_TIMES_ROMAN_24);

	int buttonX = 310, buttonW = 180, buttonH = 65;

	iSetColor(0, 120, 200);
	iFilledRectangle(buttonX, 430, buttonW, buttonH);
	iSetColor(255, 255, 255);
	drawCenteredButtonText(buttonX, 430, buttonW, buttonH, "LEVEL 1");

	iSetColor(0, 160, 100);
	iFilledRectangle(buttonX, 340, buttonW, buttonH);
	iSetColor(255, 255, 255);
	drawCenteredButtonText(buttonX, 340, buttonW, buttonH, "LEVEL 2");

	bool level3Unlocked = (highestLevelUnlocked >= 3);
	iSetColor(level3Unlocked ? 150 : 80, level3Unlocked ? 60 : 80, level3Unlocked ? 200 : 80);
	iFilledRectangle(buttonX, 250, buttonW, buttonH);
	iSetColor(255, 255, 255);
	drawCenteredButtonText(buttonX, 250, buttonW, buttonH, "LEVEL 3");

	if (!level3Unlocked)
	{
		drawCenteredText(400, 225, "LOCKED", GLUT_BITMAP_HELVETICA_12);
	}

	iSetColor(200, 0, 0);
	iFilledRectangle(buttonX, 130, buttonW, 50);
	iSetColor(255, 255, 255);
	drawCenteredButtonText(buttonX, 130, buttonW, 50, "BACK");
}

#endif
