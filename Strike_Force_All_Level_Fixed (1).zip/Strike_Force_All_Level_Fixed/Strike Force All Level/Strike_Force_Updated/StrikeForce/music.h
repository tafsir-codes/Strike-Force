#ifndef MUSIC_H
#define MUSIC_H

// ============================================================
// MUSIC.H
// Background music and sound effects using the Windows
// Multimedia Control Interface (MCI). iGraphics.h already
// includes <windows.h>. MCI is used instead of PlaySound
// because this project's audio files (background.mp3,
// gameover.mp3) are MP3s, and PlaySound only supports WAV.
// MCI can open and loop MP3 files directly.
// ============================================================

#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")

// Master on/off switches the player can toggle from the menu.
bool musicEnabled = true;
bool soundEnabled = true;

// MCI device aliases - one for the looping background track,
// one for short one-shot sound effects, so playing an effect
// never interrupts the music.
const char* MUSIC_ALIAS = "bgMusic";
const char* SFX_ALIAS = "sfxSound";

// Plays an MP3 (or WAV) file on loop in the background
// (e.g. menu theme, level theme). Only one looping track plays
// at a time; starting a new one automatically replaces the
// previous one.
void playMusicLoop(const char* filename)
{
	if (!musicEnabled)
	{
		return;
	}

	char command[256];

	// Close any previous instance of this alias first.
	mciSendStringA("close bgMusic", NULL, 0, NULL);

	sprintf_s(command, "open \"%s\" type mpegvideo alias %s", filename, MUSIC_ALIAS);
	mciSendStringA(command, NULL, 0, NULL);

	// "repeat" makes MCI loop the track automatically.
	sprintf_s(command, "play %s repeat", MUSIC_ALIAS);
	mciSendStringA(command, NULL, 0, NULL);
}

// Plays a short one-shot sound effect (gunshot, explosion, coin, etc).
void playSoundEffect(const char* filename)
{
	if (!soundEnabled)
	{
		return;
	}

	char command[256];

	// Stop and close any effect that is already playing on this alias
	// so rapid-fire effects (e.g. bullets) restart cleanly.
	mciSendStringA("close sfxSound", NULL, 0, NULL);

	sprintf_s(command, "open \"%s\" type mpegvideo alias %s", filename, SFX_ALIAS);
	mciSendStringA(command, NULL, 0, NULL);

	sprintf_s(command, "play %s", SFX_ALIAS);
	mciSendStringA(command, NULL, 0, NULL);
}

// Immediately stops the background music track.
void stopMusic()
{
	mciSendStringA("stop bgMusic", NULL, 0, NULL);
	mciSendStringA("close bgMusic", NULL, 0, NULL);
}

// Immediately stops any playing sound effect.
void stopSoundEffect()
{
	mciSendStringA("stop sfxSound", NULL, 0, NULL);
	mciSendStringA("close sfxSound", NULL, 0, NULL);
}

// Stops both music and sound effects.
void stopAllSound()
{
	stopMusic();
	stopSoundEffect();
}

void toggleMusic()
{
	musicEnabled = !musicEnabled;
	if (!musicEnabled)
	{
		stopMusic();
	}
}

void toggleSound()
{
	soundEnabled = !soundEnabled;
}

#endif
