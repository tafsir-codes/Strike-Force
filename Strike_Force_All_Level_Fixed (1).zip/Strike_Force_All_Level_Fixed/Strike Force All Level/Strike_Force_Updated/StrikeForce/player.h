#ifndef PLAYER_H
#define PLAYER_H

#include <time.h>

// ============================================================
// PLAYER.H
// The player-controlled fighter plane used in Level 3.
// Handles movement, HP, shooting, animation and drawing.
// Level 1 / Level 2 keep their own existing player variables
// (playerX/playerY, level2PlayerX/...) and are not touched by
// this header.
// ============================================================

// --------------------------------------------------------
// IMAGES
// --------------------------------------------------------

int playerPlaneImg[8];         // L3_player0.png .. L3_player7.png (propeller/animation frames)
int playerBulletImg;           // L3_bullet.png
int playerHealthBarImg[11];    // L3_healthbar000.png .. L3_healthbar010.png (0 = empty, 10 = full)

void loadPlayerImages()
{
	char path[32];

	for (int i = 0; i < 8; i++)
	{
		sprintf_s(path, "L3_player%d.png", i);
		playerPlaneImg[i] = iLoadImage(path);
	}

	playerBulletImg = iLoadImage("L3_bullet.png");

	for (int i = 0; i <= 10; i++)
	{
		sprintf_s(path, "L3_healthbar%03d.png", i);
		playerHealthBarImg[i] = iLoadImage(path);
	}
}

// --------------------------------------------------------
// PLAYER STATE
// --------------------------------------------------------

struct Player
{
	float x, y;
	int width, height;

	int frame;              // current animation frame (0..7)
	clock_t lastFrameTime;

	float velocityY;        // vertical speed, for smooth up/down movement
	float speed;             // horizontal auto-scroll speed feel (visual only, world scrolls instead)

	float maxHP, hp;

	bool isShooting;
	float bulletX, bulletY;
	clock_t lastShotTime;

	bool isInvulnerable;
	clock_t invulnerableStartTime;

	bool alive;
};

Player player;

const float PLAYER_MAX_HP = 100.0f;
const double PLAYER_SHOT_COOLDOWN = 0.35;     // seconds between shots
const double PLAYER_INVULNERABLE_TIME = 1.2;  // seconds of invulnerability after taking a hit

void resetPlayer()
{
	player.x = 130;
	player.y = 380;
	player.width = 110;
	player.height = 90;

	player.frame = 0;
	player.lastFrameTime = clock();

	player.velocityY = 0;
	player.speed = 6;

	player.maxHP = PLAYER_MAX_HP;
	player.hp = PLAYER_MAX_HP;

	player.isShooting = false;
	player.bulletX = 0;
	player.bulletY = 0;
	player.lastShotTime = 0;

	player.isInvulnerable = false;
	player.invulnerableStartTime = 0;

	player.alive = true;
}

// --------------------------------------------------------
// MOVEMENT
// --------------------------------------------------------

void movePlayerUp()
{
	player.y += player.speed;
	if (player.y > 600)
	{
		player.y = 600;
	}
}

void movePlayerDown()
{
	player.y -= player.speed;
	if (player.y < 40)
	{
		player.y = 40;
	}
}

// Moves the plane forward (right) / backward (left) across the
// screen, clamped so it can never fly off either edge.
void movePlayerForward(int screenWidth)
{
	player.x += player.speed;
	if (player.x > screenWidth - player.width)
	{
		player.x = (float)(screenWidth - player.width);
	}
}

void movePlayerBackward()
{
	player.x -= player.speed;
	if (player.x < 0)
	{
		player.x = 0;
	}
}

// --------------------------------------------------------
// SHOOTING
// --------------------------------------------------------

// Attempts to fire a bullet if the shot cooldown has elapsed.
// Returns true if a new bullet was actually fired this call.
bool playerTryShoot()
{
	double secondsSinceLastShot = (double)(clock() - player.lastShotTime) / CLOCKS_PER_SEC;

	if (!player.isShooting && secondsSinceLastShot >= PLAYER_SHOT_COOLDOWN)
	{
		player.isShooting = true;
		player.bulletX = player.x + player.width - 10;
		player.bulletY = player.y + player.height / 2 - 8;
		player.lastShotTime = clock();
		return true;
	}
	return false;
}

void updatePlayerBullet(int bulletSpeed, int screenWidth)
{
	if (player.isShooting)
	{
		player.bulletX += bulletSpeed;
		if (player.bulletX > screenWidth)
		{
			player.isShooting = false;
		}
	}
}

// --------------------------------------------------------
// DAMAGE / HEALTH
// --------------------------------------------------------

// Applies damage unless currently invulnerable. Starts a short
// invulnerability window on every hit that actually lands.
void damagePlayer(float amount)
{
	if (player.isInvulnerable || !player.alive)
	{
		return;
	}

	player.hp -= amount;
	player.isInvulnerable = true;
	player.invulnerableStartTime = clock();

	if (player.hp <= 0)
	{
		player.hp = 0;
		player.alive = false;
	}
}

void healPlayer(float amount)
{
	player.hp += amount;
	if (player.hp > player.maxHP)
	{
		player.hp = player.maxHP;
	}
}

// A direct plane-to-plane collision is an instant kill, bypassing
// invulnerability entirely (unlike damagePlayer, which respects the
// brief invulnerability window after gunfire hits). This matches a
// real head-on air collision: no amount of "recently hit" grace
// should let you survive physically ramming another aircraft.
void killPlayerInstantly()
{
	if (!player.alive)
	{
		return;
	}

	player.hp = 0;
	player.alive = false;
}

void updatePlayerInvulnerability()
{
	if (player.isInvulnerable)
	{
		double elapsed = (double)(clock() - player.invulnerableStartTime) / CLOCKS_PER_SEC;
		if (elapsed >= PLAYER_INVULNERABLE_TIME)
		{
			player.isInvulnerable = false;
		}
	}
}

// --------------------------------------------------------
// ANIMATION
// --------------------------------------------------------

void updatePlayerAnimation()
{
	double elapsed = (double)(clock() - player.lastFrameTime) / CLOCKS_PER_SEC;
	if (elapsed >= 0.06)
	{
		player.frame = (player.frame + 1) % 8;
		player.lastFrameTime = clock();
	}
}

// --------------------------------------------------------
// DRAWING
// --------------------------------------------------------

void drawPlayer()
{
	// Blink while invulnerable so the player gets clear feedback
	// that they were hit and are briefly safe.
	bool visible = true;
	if (player.isInvulnerable)
	{
		double elapsed = (double)(clock() - player.invulnerableStartTime) / CLOCKS_PER_SEC;
		visible = ((int)(elapsed * 10) % 2 == 0);
	}

	if (visible)
	{
		iShowImage((int)player.x, (int)player.y, player.width, player.height, playerPlaneImg[player.frame]);
	}

	if (player.isShooting)
	{
		iShowImage((int)player.bulletX, (int)player.bulletY, 40, 16, playerBulletImg);
	}
}

// Draws the top-left heart health bar, matching the reference
// screenshot: a single wide image whose fill level is chosen from
// 11 pre-rendered frames (0 = empty, 10 = full) based on current HP.
void drawPlayerHUD()
{
	float hpRatio = player.hp / player.maxHP;
	if (hpRatio < 0) hpRatio = 0;
	if (hpRatio > 1) hpRatio = 1;

	int frameIndex = (int)(hpRatio * 10.0f + 0.5f); // round to nearest frame
	if (frameIndex < 0) frameIndex = 0;
	if (frameIndex > 10) frameIndex = 10;

	// Sized and positioned to sit clear of the top-center score
	// text (which starts around x=340), so the two never overlap.
	int barX = 15;
	int barY = 630;
	int barWidth = 230;
	int barHeight = 46; // keeps the image's ~5:1 aspect ratio

	iShowImage(barX, barY, barWidth, barHeight, playerHealthBarImg[frameIndex]);
}

#endif
