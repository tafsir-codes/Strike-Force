#ifndef SCORE_H
#define SCORE_H

#include <stdio.h>

// ============================================================
// SCORE.H
// Centralized score / coin tracking, shared across all levels.
// The on-screen coin counter in Level 3 (top-left, "01770" style)
// is drawn from here using the coin icon image.
// ============================================================

extern int score;

// Coin icon image (assigned in loadScoreImages()).
int scoreCoinImg = -1;

// How many digits to pad the score display to (e.g. 01770).
const int SCORE_DISPLAY_DIGITS = 5;

void loadScoreImages()
{
	scoreCoinImg = iLoadImage("L3_icon_coin.png");
}

void addScore(int amount)
{
	score += amount;
}

void resetScore()
{
	score = 0;
}

// Draws the coin + zero-padded score readout used by Level 3's HUD.
// x, y is the top-left corner where the coin icon is placed.
void drawScoreHUD(int x, int y)
{
	if (scoreCoinImg != -1)
	{
		iShowImage(x, y - 24, 48, 48, scoreCoinImg);
	}

	char scoreText[16];
	char format[16];

	sprintf_s(format, "%%0%dd", SCORE_DISPLAY_DIGITS);
	sprintf_s(scoreText, format, score);

	iSetColor(230, 30, 30);
	iText(x + 58, y - 8, scoreText, GLUT_BITMAP_TIMES_ROMAN_24);
}

// Simple plain-text score draw (used by Level 1 / Level 2 style HUDs).
void drawScoreText(int x, int y)
{
	char scoreText[32];
	sprintf_s(scoreText, "Score: %d", score);

	iSetColor(255, 255, 255);
	iText(x, y, scoreText, GLUT_BITMAP_HELVETICA_18);
}

#endif
