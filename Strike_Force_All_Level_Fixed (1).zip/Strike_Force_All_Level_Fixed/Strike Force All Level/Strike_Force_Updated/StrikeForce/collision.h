#ifndef COLLISION_H
#define COLLISION_H

// ============================================================
// COLLISION.H
// Generic geometric collision helpers shared by every level.
// ============================================================

// Axis-aligned bounding box overlap test.
// Used for player vs enemy, bullet vs enemy, player vs pickup, etc.
bool checkCollision(int x1, int y1, int w1, int h1, int x2, int y2, int w2, int h2) {
	if (x1 < x2 + w2 && x1 + w1 > x2 && y1 < y2 + h2 && y1 + h1 > y2) {
		return true;
	}
	return false;
}

// Same AABB test but using float coordinates (useful for smooth bullet motion).
bool checkCollisionF(float x1, float y1, float w1, float h1, float x2, float y2, float w2, float h2) {
	if (x1 < x2 + w2 && x1 + w1 > x2 && y1 < y2 + h2 && y1 + h1 > y2) {
		return true;
	}
	return false;
}

// Circle vs circle collision (distance between centers <= sum of radii).
bool checkCircleCollision(int x1, int y1, int r1, int x2, int y2, int r2) {
	int dx = x1 - x2;
	int dy = y1 - y2;
	int distanceSquared = dx * dx + dy * dy;
	int radiusSum = r1 + r2;
	return distanceSquared <= (radiusSum * radiusSum);
}

// Point inside a rectangle (used for button / UI hit-testing).
bool checkPointInRect(int px, int py, int rx, int ry, int rw, int rh) {
	return (px >= rx && px <= rx + rw && py >= ry && py <= ry + rh);
}

#endif
