#ifndef GAMEOVER_H
#define GAMEOVER_H

#include <stdio.h>
#include <time.h>

// ============================================================
// GAMEOVER.H
// Shared "Game Over" and "Level Complete" screens, usable by
// any level. Also responsible for triggering the high-score
// save (via gamesave.h) the moment a run ends.
// ============================================================

enum GameOverReason
{
	GAMEOVER_PLAYER_DIED,
	GAMEOVER_LEVEL_COMPLETE
};

bool gameOverScreenActive = false;
GameOverReason gameOverReason = GAMEOVER_PLAYER_DIED;
int gameOverFinalScore = 0;
int gameOverLevelNumber = 1;
bool gameOverHandled = false; // guards against saving/scoring more than once per run
clock_t currentRunStartTime = 0;
double currentRunElapsedSeconds = 0.0;

// Call once, the instant the player dies or clears the level.
// levelNumber identifies which level's high-score slot to update
// (1, 2, or 3).
void startRunTimer()
{
	currentRunStartTime = clock();
	currentRunElapsedSeconds = 0.0;
}

double getCurrentRunTime()
{
	if (currentRunStartTime == 0) return currentRunElapsedSeconds;
	return (double)(clock() - currentRunStartTime) / CLOCKS_PER_SEC;
}

void triggerGameOver(GameOverReason reason, int finalScore, int levelNumber)
{
	if (gameOverHandled)
	{
		return;
	}

	gameOverScreenActive = true;
	gameOverReason = reason;
	gameOverFinalScore = finalScore;
	gameOverLevelNumber = levelNumber;
	gameOverHandled = true;
	currentRunElapsedSeconds = getCurrentRunTime();

	updateHighScoreIfNeeded(levelNumber, finalScore, currentRunElapsedSeconds, reason == GAMEOVER_LEVEL_COMPLETE);

	// The Game Over / Level Complete screen always plays the menu
	// theme, regardless of which level was just played.
	playMusicLoop("Audios/menu_music.mp3");

	if (reason == GAMEOVER_LEVEL_COMPLETE)
	{
		playSoundEffect("Audios/gameover.mp3");
	}
}

void resetGameOverState()
{
	gameOverScreenActive = false;
	gameOverHandled = false;
	gameOverFinalScore = 0;
	currentRunElapsedSeconds = 0.0;
}

// Draws the full-screen Game Over / Level Complete result screen,
// matching the reference layout: dark background, colored title,
// "Score: X" / "Best: Y" readout, and three stacked buttons -
// green RETRY, dark red MAIN MENU, and a BACK button (to Level
// Selection) - all centered on screen below the score/best text.
// Button hit-boxes are exposed as constants below so iMouse() in
// iMain.cpp can wire up clicks using the exact same coordinates
// this function draws with.
const int GAMEOVER_BTN_W = 180;
const int GAMEOVER_BTN_H = 55;
const int GAMEOVER_BTN_X = 400 - GAMEOVER_BTN_W / 2; // centered on an 800-wide screen
const int GAMEOVER_BTN_GAP = 20;

const int GAMEOVER_RETRY_BTN_X = GAMEOVER_BTN_X;
const int GAMEOVER_RETRY_BTN_Y = 380;
const int GAMEOVER_RETRY_BTN_W = GAMEOVER_BTN_W;
const int GAMEOVER_RETRY_BTN_H = GAMEOVER_BTN_H;

const int GAMEOVER_MENU_BTN_X = GAMEOVER_BTN_X;
const int GAMEOVER_MENU_BTN_Y = GAMEOVER_RETRY_BTN_Y - (GAMEOVER_BTN_H + GAMEOVER_BTN_GAP);
const int GAMEOVER_MENU_BTN_W = GAMEOVER_BTN_W;
const int GAMEOVER_MENU_BTN_H = GAMEOVER_BTN_H;

const int GAMEOVER_BACK_BTN_X = GAMEOVER_BTN_X;
const int GAMEOVER_BACK_BTN_Y = GAMEOVER_MENU_BTN_Y - (GAMEOVER_BTN_H + GAMEOVER_BTN_GAP);
const int GAMEOVER_BACK_BTN_W = GAMEOVER_BTN_W;
const int GAMEOVER_BACK_BTN_H = GAMEOVER_BTN_H;

void drawGameOverScreen(int screenWidth, int screenHeight)
{
	iSetColor(13, 13, 24);
	iFilledRectangle(0, 0, screenWidth, screenHeight);

	if (gameOverReason == GAMEOVER_PLAYER_DIED)
	{
		iSetColor(210, 40, 50);
		drawCenteredText(screenWidth / 2, screenHeight - 100, "GAME OVER", GLUT_BITMAP_TIMES_ROMAN_24);
	}
	else
	{
		iSetColor(60, 190, 90);
		drawCenteredText(screenWidth / 2, screenHeight - 100, "LEVEL COMPLETE!", GLUT_BITMAP_TIMES_ROMAN_24);
	}

	char scoreLine[64], bestLine[64], timeLine[64];
	char timeText[20], bestTimeText[20];
	formatRunTime(currentRunElapsedSeconds, timeText, sizeof(timeText));
	formatRunTime(bestTimeByLevel[gameOverLevelNumber - 1], bestTimeText, sizeof(bestTimeText));

	sprintf_s(scoreLine, "Score: %d", gameOverFinalScore);
	sprintf_s(timeLine, "Time: %s", timeText);
	sprintf_s(bestLine, "Best: %s  |  Score: %d", bestTimeText, highScoreByLevel[gameOverLevelNumber - 1]);

	iSetColor(255, 255, 255);
	drawCenteredText(screenWidth / 2, screenHeight - 165, scoreLine, GLUT_BITMAP_HELVETICA_18);
	drawCenteredText(screenWidth / 2, screenHeight - 195, timeLine, GLUT_BITMAP_HELVETICA_18);
	iSetColor(255, 210, 0);
	drawCenteredText(screenWidth / 2, screenHeight - 225, bestLine, GLUT_BITMAP_HELVETICA_18);

	iSetColor(20, 140, 70);
	iFilledRectangle(GAMEOVER_RETRY_BTN_X, GAMEOVER_RETRY_BTN_Y, GAMEOVER_RETRY_BTN_W, GAMEOVER_RETRY_BTN_H);
	iSetColor(255, 255, 255);
	drawCenteredButtonText(GAMEOVER_RETRY_BTN_X, GAMEOVER_RETRY_BTN_Y, GAMEOVER_RETRY_BTN_W, GAMEOVER_RETRY_BTN_H, "RETRY");

	iSetColor(120, 25, 25);
	iFilledRectangle(GAMEOVER_MENU_BTN_X, GAMEOVER_MENU_BTN_Y, GAMEOVER_MENU_BTN_W, GAMEOVER_MENU_BTN_H);
	iSetColor(255, 255, 255);
	drawCenteredButtonText(GAMEOVER_MENU_BTN_X, GAMEOVER_MENU_BTN_Y, GAMEOVER_MENU_BTN_W, GAMEOVER_MENU_BTN_H, "MAIN MENU");

	iSetColor(70, 70, 80);
	iFilledRectangle(GAMEOVER_BACK_BTN_X, GAMEOVER_BACK_BTN_Y, GAMEOVER_BACK_BTN_W, GAMEOVER_BACK_BTN_H);
	iSetColor(255, 255, 255);
	drawCenteredButtonText(GAMEOVER_BACK_BTN_X, GAMEOVER_BACK_BTN_Y, GAMEOVER_BACK_BTN_W, GAMEOVER_BACK_BTN_H, "BACK");
}
#endif
