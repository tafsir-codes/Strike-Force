#ifndef ENEMY_H
#define ENEMY_H

#include <stdlib.h>
#include <time.h>
#include <math.h>

extern clock_t level3RunStartTime;

// ============================================================
// ENEMY.H
// Enemy fighter planes used in Level 3. Handles spawning,
// simple sine-wave flight movement, HP, explosion-on-death
// animation, and drawing. Level 1 / Level 2 keep their own
// existing enemy code and are not touched by this header.
// ============================================================

const int ENEMY_MAX_SLOTS = 6;
const int ENEMY_WIDTH = 90;
const int ENEMY_HEIGHT = 62;
const float ENEMY_MAX_HP = 20.0f;

const int ENEMY_BULLET_WIDTH = 40;
const int ENEMY_BULLET_HEIGHT = 16;
const float ENEMY_BULLET_SPEED = 9.0f;         // moves left toward the player
const double ENEMY_FIRE_COOLDOWN_MIN = 1.2;    // seconds between shots (randomized per-enemy)
const double ENEMY_FIRE_COOLDOWN_MAX = 2.6;

int enemyPlaneImg;      // L3_enemy.png
int enemyExplosionImg;  // L3_explosion.png
int enemyBulletImg;     // L3_enemy_bullet.png

void loadEnemyImages()
{
	enemyPlaneImg = iLoadImage("L3_enemy.png");
	enemyExplosionImg = iLoadImage("L3_explosion.png");
	enemyBulletImg = iLoadImage("L3_enemy_bullet.png");
}

struct Enemy
{
	bool alive;
	float x, y;
	float baseY;         // center line of its sine-wave flight path
	float wavePhase;     // current position along the sine wave
	float speed;

	float hp;

	bool exploding;
	clock_t explosionStartTime;

	// Enemy gunfire
	bool isShooting;
	float bulletX, bulletY;
	clock_t lastShotTime;
	double fireCooldown;
	float speedMultiplier;
};

Enemy enemies[ENEMY_MAX_SLOTS];

clock_t lastEnemySpawnTime;
double enemySpawnDelay;
bool enemySpawnTimerStarted = false;

const double ENEMY_EXPLOSION_DURATION = 0.5; // seconds the explosion frame stays visible

void resetEnemies()
{
	for (int i = 0; i < ENEMY_MAX_SLOTS; i++)
	{
		enemies[i].alive = false;
		enemies[i].exploding = false;
		enemies[i].isShooting = false;
		enemies[i].speedMultiplier = 1.0f;
	}
	enemySpawnTimerStarted = false;
}

int findFreeEnemySlot()
{
	for (int i = 0; i < ENEMY_MAX_SLOTS; i++)
	{
		if (!enemies[i].alive && !enemies[i].exploding)
		{
			return i;
		}
	}
	return -1;
}

int countActiveEnemies()
{
	int count = 0;
	for (int i = 0; i < ENEMY_MAX_SLOTS; i++)
	{
		if (enemies[i].alive)
		{
			count++;
		}
	}
	return count;
}

// Spawns a new enemy just off the right edge of the screen at a
// random height, with a small random delay between spawns so
// enemies do not appear in a predictable rhythm.
void spawnEnemies(int screenWidth, int maxActiveEnemies)
{
	clock_t now = clock();

	if (!enemySpawnTimerStarted)
	{
		enemySpawnTimerStarted = true;
		lastEnemySpawnTime = now;
		enemySpawnDelay = 1.2 + (rand() % 5) * 0.3; // 1.2 - 2.4s
	}

	double secondsSinceLastSpawn = (double)(now - lastEnemySpawnTime) / CLOCKS_PER_SEC;
	if (secondsSinceLastSpawn < enemySpawnDelay)
	{
		return;
	}

	if (countActiveEnemies() >= maxActiveEnemies)
	{
		return;
	}

	int i = findFreeEnemySlot();
	if (i == -1)
	{
		return;
	}

	enemies[i].alive = true;
	enemies[i].exploding = false;
	enemies[i].x = (float)(screenWidth + 40);
	enemies[i].baseY = (float)(150 + rand() % 400);
	enemies[i].y = enemies[i].baseY;
	enemies[i].wavePhase = (float)(rand() % 360);
	enemies[i].speed = 3.0f + (rand() % 3);
	// One occasional fast plane makes the stream less predictable,
	// but its bonus is deliberately modest.
	enemies[i].speedMultiplier = (rand() % 100 < 18) ? 1.25f : 1.0f;
	enemies[i].hp = ENEMY_MAX_HP;

	enemies[i].isShooting = false;
	enemies[i].bulletX = 0;
	enemies[i].bulletY = 0;
	enemies[i].lastShotTime = clock();
	enemies[i].fireCooldown = ENEMY_FIRE_COOLDOWN_MIN +
		((double)(rand() % 100) / 100.0) * (ENEMY_FIRE_COOLDOWN_MAX - ENEMY_FIRE_COOLDOWN_MIN);

	lastEnemySpawnTime = now;
	enemySpawnDelay = 1.2 + (rand() % 5) * 0.3;
}

// Moves all active enemies left in a gentle sine-wave pattern,
// advances explosion timers for enemies that just died, and
// handles each alive enemy's independent gunfire timer + bullet
// movement toward the player (leftward across the screen).
void updateEnemies()
{
	for (int i = 0; i < ENEMY_MAX_SLOTS; i++)
	{
		if (enemies[i].alive)
		{
			// Gradual difficulty: +10% after roughly 30s, +20% after
			// 60s, capped at +30%. This keeps the level completable.
			double runSeconds = (double)(clock() - level3RunStartTime) / CLOCKS_PER_SEC;
			float difficultyMultiplier = 1.0f;
			if (runSeconds >= 90.0) difficultyMultiplier = 1.30f;
			else if (runSeconds >= 60.0) difficultyMultiplier = 1.20f;
			else if (runSeconds >= 30.0) difficultyMultiplier = 1.10f;

			float effectiveSpeed = enemies[i].speed * difficultyMultiplier * enemies[i].speedMultiplier;
			if (effectiveSpeed > 8.0f) effectiveSpeed = 8.0f;
			enemies[i].x -= effectiveSpeed;
			enemies[i].wavePhase += 2.0f;
			enemies[i].y = enemies[i].baseY + (float)(sin(enemies[i].wavePhase * 3.14159 / 180.0) * 40.0);

			if (enemies[i].x < -ENEMY_WIDTH)
			{
				enemies[i].alive = false;
			}

			// --- Gunfire ---
			if (!enemies[i].isShooting)
			{
				double secondsSinceLastShot = (double)(clock() - enemies[i].lastShotTime) / CLOCKS_PER_SEC;
				if (secondsSinceLastShot >= enemies[i].fireCooldown)
				{
					enemies[i].isShooting = true;
					enemies[i].bulletX = enemies[i].x - 10;
					enemies[i].bulletY = enemies[i].y + ENEMY_HEIGHT / 2 - ENEMY_BULLET_HEIGHT / 2;
					enemies[i].lastShotTime = clock();

					// Pick a fresh random cooldown for the NEXT shot.
					enemies[i].fireCooldown = ENEMY_FIRE_COOLDOWN_MIN +
						((double)(rand() % 100) / 100.0) * (ENEMY_FIRE_COOLDOWN_MAX - ENEMY_FIRE_COOLDOWN_MIN);
				}
			}
			else
			{
				enemies[i].bulletX -= ENEMY_BULLET_SPEED;
				if (enemies[i].bulletX < -ENEMY_BULLET_WIDTH)
				{
					enemies[i].isShooting = false;
				}
			}
		}
		else if (enemies[i].exploding)
		{
			double elapsed = (double)(clock() - enemies[i].explosionStartTime) / CLOCKS_PER_SEC;
			if (elapsed >= ENEMY_EXPLOSION_DURATION)
			{
				enemies[i].exploding = false;
			}
		}
	}
}

// Applies damage to one enemy. If it dies, starts the explosion
// animation in its place and returns true so the caller can add
// score / play a sound effect.
bool damageEnemy(int index, float amount)
{
	if (!enemies[index].alive)
	{
		return false;
	}

	enemies[index].hp -= amount;

	if (enemies[index].hp <= 0)
	{
		enemies[index].alive = false;
		enemies[index].exploding = true;
		enemies[index].explosionStartTime = clock();
		return true;
	}

	return false;
}

void drawEnemies()
{
	for (int i = 0; i < ENEMY_MAX_SLOTS; i++)
	{
		if (enemies[i].alive)
		{
			iShowImage((int)enemies[i].x, (int)enemies[i].y, ENEMY_WIDTH, ENEMY_HEIGHT, enemyPlaneImg);

			if (enemies[i].isShooting)
			{
				iShowImage((int)enemies[i].bulletX, (int)enemies[i].bulletY, ENEMY_BULLET_WIDTH, ENEMY_BULLET_HEIGHT, enemyBulletImg);
			}
		}
		else if (enemies[i].exploding)
		{
			iShowImage((int)enemies[i].x - 20, (int)enemies[i].y - 30, 130, 130, enemyExplosionImg);
		}
	}
}

#endif
