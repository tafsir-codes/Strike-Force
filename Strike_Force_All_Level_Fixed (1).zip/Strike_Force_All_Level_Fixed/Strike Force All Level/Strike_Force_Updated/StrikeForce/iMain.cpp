#include "iGraphics.h"
#include "collision.h"
#include "gamesave.h"
#include "music.h"
#include "menu.h"
#include <stdio.h>
#include <stdlib.h> // needed for rand() - used for enemy's random jump
#include <time.h>   // needed for clock() - used to measure time between key presses
#include "gameover.h"
#include "level1.h"
#include "level2.h"
#include "level3.h"

// Game States:
// 0 = Main Menu
// 1 = Playing (also covers the Game Over / Win overlay - see
//     gameOverScreenActive in gameover.h - drawn on top of
//     gameplay rather than as a separate state, so RETRY can
//     restart in place without a state transition)
// 4 = Instructions
// 5 = Level Selection
// 6 = High Score
int gameState = 0;
int score = 0;

// Current level 
// 1 = Level 1
// 2 = Level 2 
// 3 = Level 3
int currentLevel = 1;

// Image Variables (menu backgrounds, loaded here since they are shared / not level-specific)
int bg1, bg2;

const int GAME_EXIT_BTN_X = 690;
const int GAME_EXIT_BTN_Y = 670;
const int GAME_EXIT_BTN_W = 90;
const int GAME_EXIT_BTN_H = 30;

void drawGameExitButton()
{
	// Exit button is kept in the top-right corner, completely
	// separated from the bottom-right Score box used by every level.
	iSetColor(150, 0, 0);
	iFilledRectangle(GAME_EXIT_BTN_X, GAME_EXIT_BTN_Y, GAME_EXIT_BTN_W, GAME_EXIT_BTN_H);

	iSetColor(255, 255, 255);
	drawCenteredButtonText(GAME_EXIT_BTN_X, GAME_EXIT_BTN_Y, GAME_EXIT_BTN_W, GAME_EXIT_BTN_H, "EXIT");
}

void iDraw() {
	iClear();

	if (gameState == 0) {
		drawMenu();
	}
	else if (gameState == 4) {
		drawInstructions();
	}
	else if (gameState == 5)
	{
		drawLevelSelection();
	}
	else if (gameState == 6)
	{
		drawHighScoreScreen();
	}
	else if (gameState == 7)
	{
		drawDescriptionScreen();
	}
	else if (gameState == 8)
	{
		drawAboutScreen();
	}
	else if (gameState == 1)
	{
		// --------------------------------------------------------
		// LEVEL 1
		// --------------------------------------------------------

		if (currentLevel == 1)
		{
			drawLevel1();
		}

		// --------------------------------------------------------
		// LEVEL 2
		// --------------------------------------------------------

		else if (currentLevel == 2)
		{
			drawLevel2();
		}

		// --------------------------------------------------------
		// LEVEL 3
		// --------------------------------------------------------

		else if (currentLevel == 3)
		{
			drawLevel3();
		}

		// Exit button for all levels - suppressed while the Game
		// Over / Level Complete overlay is showing, since that
		// screen has its own RETRY / MAIN MENU / BACK buttons and
		// should not have EXIT drawn on top of it.
		if (!gameOverScreenActive)
		{
			drawGameExitButton();
		}
	}
}


void iMouse(int button, int state, int mx, int my)
{
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		// ============================
		// EXIT DURING GAME
		// ============================
		if (gameState == 1 && mx >= GAME_EXIT_BTN_X && mx <= GAME_EXIT_BTN_X + GAME_EXIT_BTN_W &&
			my >= GAME_EXIT_BTN_Y && my <= GAME_EXIT_BTN_Y + GAME_EXIT_BTN_H)
		{
			gameState = 5;
			playMusicLoop("Audios/menu_music.mp3");
			return;
		}

		// ============================
		// GAME OVER / LEVEL COMPLETE OVERLAY
		// (drawn on top of gameState == 1 while playing any level)
		// ============================
		if (gameState == 1 && gameOverScreenActive)
		{
			// RETRY button. Accept both possible Y orientations so the
			// result screen remains clickable in maximized/windowed mode.
			bool retryHit =
				(mx >= GAMEOVER_RETRY_BTN_X && mx <= GAMEOVER_RETRY_BTN_X + GAMEOVER_RETRY_BTN_W &&
				 ((my >= GAMEOVER_RETRY_BTN_Y && my <= GAMEOVER_RETRY_BTN_Y + GAMEOVER_RETRY_BTN_H) ||
				  (700 - my >= GAMEOVER_RETRY_BTN_Y && 700 - my <= GAMEOVER_RETRY_BTN_Y + GAMEOVER_RETRY_BTN_H)));
			if (retryHit)
			{
				// Clear the result state BEFORE rebuilding the level.
				// Every retry is a genuinely new run, never a resume.
				resetGameOverState();

				if (currentLevel == 1)
					resetLevel1();
				else if (currentLevel == 2)
					resetLevel2();
				else if (currentLevel == 3)
					resetLevel3();

				gameState = 1;
				playMusicLoop("Audios/level_music.mp3");
				return;
			}

			// MAIN MENU button
			if (mx >= GAMEOVER_MENU_BTN_X && mx <= GAMEOVER_MENU_BTN_X + GAMEOVER_MENU_BTN_W &&
				my >= GAMEOVER_MENU_BTN_Y && my <= GAMEOVER_MENU_BTN_Y + GAMEOVER_MENU_BTN_H)
			{
				gameState = 0;
				playMusicLoop("Audios/menu_music.mp3");
				return;
			}

			// BACK button - returns to Level Selection
			if (mx >= GAMEOVER_BACK_BTN_X && mx <= GAMEOVER_BACK_BTN_X + GAMEOVER_BACK_BTN_W &&
				my >= GAMEOVER_BACK_BTN_Y && my <= GAMEOVER_BACK_BTN_Y + GAMEOVER_BACK_BTN_H)
			{
				gameState = 5;
				playMusicLoop("Audios/menu_music.mp3");
				return;
			}

			// While this overlay is active, ignore all other clicks
			// (e.g. clicks that would otherwise hit the EXIT button
			// underneath it).
			return;
		}

		// ============================
		// MAIN MENU
		// ============================
		if (gameState == 0)
		{
			// START button
			if (mx >= MENU_BTN_X && mx <= MENU_BTN_X + MENU_BTN_W &&
				my >= MENU_START_BTN_Y && my <= MENU_START_BTN_Y + MENU_BTN_H)
			{
				gameState = 5;   // Go to Level Selection
			}

			// INSTRUCTIONS button
			if (mx >= MENU_BTN_X && mx <= MENU_BTN_X + MENU_BTN_W &&
				my >= MENU_INSTRUCTIONS_BTN_Y && my <= MENU_INSTRUCTIONS_BTN_Y + MENU_BTN_H)
			{
				gameState = 4;
			}

			// HIGH SCORE button
			if (mx >= MENU_BTN_X && mx <= MENU_BTN_X + MENU_BTN_W &&
				my >= MENU_HIGHSCORE_BTN_Y && my <= MENU_HIGHSCORE_BTN_Y + MENU_BTN_H)
			{
				gameState = 6;
			}

			// DESCRIPTION button
			if (mx >= MENU_BTN_X && mx <= MENU_BTN_X + MENU_BTN_W &&
				my >= MENU_STORY_BTN_Y && my <= MENU_STORY_BTN_Y + MENU_BTN_H)
			{
				gameState = 7;
			}

			// ABOUT button
			if (mx >= MENU_BTN_X && mx <= MENU_BTN_X + MENU_BTN_W &&
				my >= MENU_ABOUT_BTN_Y && my <= MENU_ABOUT_BTN_Y + MENU_BTN_H)
			{
				gameState = 8;
			}

			// EXIT button - closes the application immediately
			if (mx >= MENU_BTN_X && mx <= MENU_BTN_X + MENU_BTN_W &&
				my >= MENU_EXIT_BTN_Y && my <= MENU_EXIT_BTN_Y + MENU_BTN_H)
			{
				exit(0);
			}
		}

		// ============================
		// INSTRUCTIONS
		// ============================
		else if (gameState == 4)
		{
			// BACK button
			if (mx >= 350 && mx <= 450 &&
				my >= 130 && my <= 180)
			{
				gameState = 0;
			}
		}

		// ============================
		// HIGH SCORE
		// ============================
		else if (gameState == 6)
		{
			// BACK button
			if (mx >= 350 && mx <= 450 &&
				my >= 75 && my <= 125)
			{
				gameState = 0;
			}
		}

		// ============================
		// DESCRIPTION
		// ============================
		else if (gameState == 7)
		{
			// BACK button
			if (mx >= 350 && mx <= 450 &&
				my >= 150 && my <= 200)
			{
				gameState = 0;
			}
		}

		// ============================
		// ABOUT
		// ============================
		else if (gameState == 8)
		{
			// BACK button
			if (mx >= 350 && mx <= 450 &&
				my >= 150 && my <= 200)
			{
				gameState = 0;
			}
		}

		// ============================
		// LEVEL SELECTION
		// ============================
		else if (gameState == 5)
		{
			// Level Selection buttons are vertically aligned and centered.

			// LEVEL 1
			if (mx >= 310 && mx <= 490 &&
				my >= 430 && my <= 495)
			{
				currentLevel = 1;
				resetLevel1();
				rememberLastLevel(1);
				playMusicLoop("Audios/level_music.mp3");
				gameState = 1;
			}

			// LEVEL 2
			else if (mx >= 310 && mx <= 490 &&
				my >= 340 && my <= 405)
			{
				currentLevel = 2;

				resetLevel2();
				rememberLastLevel(2);
				playMusicLoop("Audios/level_music.mp3");
				gameState = 1;
			}

			// LEVEL 3 (unlocked once the player has cleared enough to reach it)
			else if (mx >= 310 && mx <= 490 &&
				my >= 250 && my <= 315)
			{
				if (highestLevelUnlocked >= 3)
				{
					currentLevel = 3;
					resetLevel3();
					rememberLastLevel(3);
					playMusicLoop("Audios/level_music.mp3");
					gameState = 1;
				}
				// else: still locked, do nothing
			}

			// BACK
			else if (mx >= 310 && mx <= 490 &&
				my >= 130 && my <= 180)
			{
				gameState = 0;
			}
		}
	}
}
/***********************Not used in this game*******************************/
void iKeyboard(unsigned char key) {}
void iSpecialKeyboard(unsigned char key) {}
void iPassiveMouseMove(int mx, int my) {}
void iMouseMove(int mx, int my) {}
/**************************************************************************/

// iGraphics.h calls this directly from its internal Win32 keyboard
// handler (keypressHandler) on every key event, independent of the
// iSetTimer game loop. It must exist globally with this exact name.
// Level 1 is the only level that relied on this particular hook
// (its original design polls movement/shoot keys here); Levels 2
// and 3 poll input from inside their own update functions instead,
// called via gameLoop() on the timer.
void fixedUpdate()
{
	if (gameState == 1 && currentLevel == 1)
	{
		fixedUpdateLevel1();
	}
}


// The game's whole layout is drawn on a fixed 800x700 logical
// coordinate system (set up once in iInitialize). When the window
// is resized or maximized to a different shape, this stretches that
// fixed content to fill the ENTIRE window edge-to-edge - no black
// bars on any side, matching how the reference screenshots look.
// The tradeoff is that images can look slightly stretched
// horizontally or vertically if the window's shape doesn't match
// 800:700, but nothing is ever cropped or bordered.
void onWindowReshape(int newWidth, int newHeight)
{
	glViewport(0, 0, newWidth, newHeight);
}

// Replaces iGraphics.h's own glutMouseFunc registration (GLUT only
// keeps the most recently registered callback). iStart() below
// registers iGraphics.h's mouseHandlerFF and then calls
// glutMainLoop(), which never returns, so there is no line of code
// that runs "after iStart() but before the loop starts" - any
// re-registration has to happen from INSIDE a callback that GLUT
// itself invokes once the loop is already running. gameLoop() (the
// iSetTimer callback) fires every 50ms starting immediately, so it
// is used here, once, to install this handler on its very first
// call.
//
// This receives TRUE raw window-pixel coordinates directly from
// GLUT (top-down, unlike iGraphics.h's internal iMouseY, which
// flips using a hardcoded 700 and is therefore wrong for any window
// size other than exactly 800x700). Since the game content now
// stretches to fill the whole window (see onWindowReshape above),
// converting a click is a straightforward proportional scale from
// the real window size down to the fixed 800x700 logical size, then
// forwards the corrected click to iMouse() so every existing click
// handler in this file keeps working unchanged.
void rawMouseHandler(int button, int state, int rawPixelX, int rawPixelYTopDown)
{
	int windowWidth = glutGet(GLUT_WINDOW_WIDTH);
	int windowHeight = glutGet(GLUT_WINDOW_HEIGHT);

	int logicalX = (int)(((float)rawPixelX / (float)windowWidth) * 800.0f);
	int logicalYFromTop = (int)(((float)rawPixelYTopDown / (float)windowHeight) * 700.0f);
	int logicalY = 700 - logicalYFromTop; // flip to bottom-left origin

	// The result screen must remain clickable even if a GLUT/Windows
	// configuration supplies the mouse Y coordinate in the opposite
	// orientation. Prefer the normal converted coordinate, but if the
	// click is on a result-screen button only under the alternate
	// orientation, forward that alternate coordinate instead. This is
	// especially important for RETRY, which must always start a fresh run.
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN &&
		gameState == 1 && gameOverScreenActive)
	{
		int alternateY = logicalYFromTop;
		bool normalHitsRetry =
			logicalY >= GAMEOVER_RETRY_BTN_Y &&
			logicalY <= GAMEOVER_RETRY_BTN_Y + GAMEOVER_RETRY_BTN_H &&
			logicalX >= GAMEOVER_RETRY_BTN_X &&
			logicalX <= GAMEOVER_RETRY_BTN_X + GAMEOVER_RETRY_BTN_W;
		bool alternateHitsRetry =
			 alternateY >= GAMEOVER_RETRY_BTN_Y &&
			 alternateY <= GAMEOVER_RETRY_BTN_Y + GAMEOVER_RETRY_BTN_H &&
			 logicalX >= GAMEOVER_RETRY_BTN_X &&
			 logicalX <= GAMEOVER_RETRY_BTN_X + GAMEOVER_RETRY_BTN_W;

		if (alternateHitsRetry && !normalHitsRetry)
		{
			logicalY = alternateY;
		}
	}

	iMouse(button, state, logicalX, logicalY);
}

bool rawMouseHandlerInstalled = false;

// Uses the real Win32 "maximize" (SW_MAXIMIZE) on the game's own
// window, found by its exact title ("Strike Force", set in
// iInitialize below). This is different from manually resizing the
// window to the screen's dimensions: SW_MAXIMIZE properly registers
// with Windows as a maximized state, so the title bar's
// maximize/restore button correctly shows the restore icon and
// remembers the original windowed size/position to snap back to -
// exactly as if the person had clicked maximize themselves.
void maximizeGameWindow()
{
	HWND windowHandle = FindWindowA(NULL, "Strike Force");
	if (windowHandle != NULL)
	{
		ShowWindow(windowHandle, SW_MAXIMIZE);
	}
}

// Combined update function - runs both game logic and enemy movement every tick
void gameLoop()
{
	// One-time setup that must happen after GLUT's main loop has
	// actually started (see rawMouseHandler's comment above for why
	// this can't simply go after iStart() in main()). The window
	// also is not findable by FindWindowA until the message loop is
	// pumping, so maximizing needs to wait until here too.
	if (!rawMouseHandlerInstalled)
	{
		glutMouseFunc(rawMouseHandler);
		maximizeGameWindow();
		rawMouseHandlerInstalled = true;
	}

	if (gameState != 1)
	{
		return;
	}

	// --------------------------------------------------------
	// LEVEL 1
	// --------------------------------------------------------

	if (currentLevel == 1)
	{
		updateLevel1();
	}

	// --------------------------------------------------------
	// LEVEL 2
	// --------------------------------------------------------

	else if (currentLevel == 2)
	{
		updateLevel2();
	}

	// --------------------------------------------------------
	// LEVEL 3
	// --------------------------------------------------------

	else if (currentLevel == 3)
	{
		updateLevel3();
	}
}

int main() {
	srand((unsigned int)time(NULL));

	iInitialize(800, 700, "Strike Force");

	// Keep the game content filling the whole window edge-to-edge
	// whenever it's resized or maximized (see onWindowReshape above).
	glutReshapeFunc(onWindowReshape);

	// Load saved progress (high score, unlocked levels) from savegame.txt
	loadGameData();

	// Load Level 1 background (also used by the main menu)
	bg1 = iLoadImage("Battleground1.png");
	bg2 = iLoadImage("Battleground2.png");

	// Load Level 1 images
	loadLevel1Images();

	// Load Level 2 images
	loadLevel2Images();
	resetLevel2();

	// Load Level 3 images
	loadLevel3Images();

	// Start menu music
	playMusicLoop("Audios/menu_music.mp3");

	// Set timer
	iSetTimer(50, gameLoop);

	// The window is maximized to fill the screen from inside
	// gameLoop()'s first call (see rawMouseHandlerInstalled above)
	// rather than here, since window-size/position calls have no
	// effect when made before glutMainLoop() has started.
	iStart();

	return 0;
}
