#ifndef LEVEL1_H
#define LEVEL1_H

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include "gamesave.h"

// ============================================================
// LEVEL 1 - This is the original gameplay that used to live
// directly inside iMain.cpp. It has been moved here, unchanged
// in behavior, so that every level now follows the same
// one-header-per-level structure (see level2.h, level3.h).
// ============================================================

// ------------------------------------------------------------
// External variables coming from iMain.cpp
// ------------------------------------------------------------

extern int gameState;
extern int score;
extern int bg2;

// Level 3's heart health-bar images (L3_healthbar000..010.png), reused
// here so Level 1's HUD matches Level 3's look exactly.
extern int playerHealthBarImg[11];
void loadPlayerImages(); // declared in player.h - loads playerHealthBarImg among others

// ============================================================
// IMAGE VARIABLES
// ============================================================

int level1PlayerImg[7];
int level1EnemyImg[9];

// ============================================================
// ENTITY VARIABLES
// ============================================================

int level1PlayerX = 100, level1PlayerY = 100;
int level1BulletX = 0, level1BulletY = 0;
float level1BgX = 0; // Tracks how far the background has scrolled
bool level1IsShooting = false;
clock_t level1LastShotTime = 0;
int level1EnemyX = 800, level1EnemyY = 100;
int level1EnemyFrame = 0;
int level1PlayerFrame = 1;

// Jump physics for player
bool level1IsJumping = false;
float level1PlayerVelocityY = 0;
int level1PlayerGroundY = 100;

// Multi-jump tracking (up to 3 jumps total per airborne sequence)
bool level1WasUpKeyDown = false;
clock_t level1LastUpPressTime = 0;
int level1JumpCount = 0;
bool level1MultiJumpActive = false;

// Random jump physics for enemy
bool level1EnemyJumping = false;
float level1EnemyVelocityY = 0;
int level1EnemyGroundY = 100;

// Enemy forward-speed randomization
int level1EnemyBaseSpeed = 5;
float level1EnemySpeedMultiplier = 1.0f;

// Enemy respawn after being dodged via double jump OR after hitting player
bool level1EnemyWaitingRespawn = false;
clock_t level1RespawnStartTime = 0;

// Player invulnerability system (brief grace period after taking damage)
bool level1IsInvulnerable = false;
clock_t level1InvulnerableStartTime = 0;

// ------------------------------------------------------------
// HEALTH SYSTEM (new) - matches Level 3's heart HP bar look
// ------------------------------------------------------------

const float LEVEL1_PLAYER_MAX_HP = 100.0f;
const float LEVEL1_COLLISION_DAMAGE = 25.0f;   // damage from directly touching the enemy
float level1PlayerHP = LEVEL1_PLAYER_MAX_HP;

// ------------------------------------------------------------
// HEALTH PICKUP (apple) - collecting one now counts toward the
// win condition instead of healing HP.
// ------------------------------------------------------------

int level1HealthPickupImg = 0;
bool level1HealthPickupActive = false;
int level1HealthPickupX = 0, level1HealthPickupY = 0;
const int LEVEL1_HEALTH_PICKUP_SIZE = 45;
clock_t level1LastHealthPickupTime = 0;
double level1HealthPickupSpawnCooldown = 6.0; // seconds between pickups, randomized each spawn

// ------------------------------------------------------------
// WIN CONDITION (new) - collect 10 apples AND kill 10 enemies.
// Tracked separately from score, which is kept only for the
// existing high-score display.
// ------------------------------------------------------------

const int LEVEL1_APPLES_REQUIRED = 10;
const int LEVEL1_KILLS_REQUIRED = 10;
int level1ApplesCollected = 0;
int level1EnemiesKilled = 0;

// ============================================================
// LOAD / RESET
// ============================================================

void loadLevel1Images()
{
	char imgpath[20];

	for (int i = 0; i <= 6; i++)
	{
		sprintf_s(imgpath, "p%d.png", i);
		level1PlayerImg[i] = iLoadImage(imgpath);
	}

	char imgPath[20];

	for (int i = 0; i <= 8; i++)
	{
		sprintf_s(imgPath, "e%d.png", i);
		level1EnemyImg[i] = iLoadImage(imgPath);
	}

	// Reuse Level 3's heart health-bar frames for Level 1's HUD.
	char barPath[32];
	for (int i = 0; i <= 10; i++)
	{
		sprintf_s(barPath, "L3_healthbar%03d.png", i);
		playerHealthBarImg[i] = iLoadImage(barPath);
	}

	// Health pickup apple
	level1HealthPickupImg = iLoadImage("health.png");
}

void resetLevel1()
{
	level1PlayerX = 100;
	level1PlayerY = 100;
	level1BulletX = 0;
	level1BulletY = 0;
	level1BgX = 0;
	level1IsShooting = false;
	level1LastShotTime = 0;
	level1EnemyX = 800;
	level1EnemyY = 100;
	level1EnemyFrame = 0;
	level1PlayerFrame = 1;

	level1IsJumping = false;
	level1PlayerVelocityY = 0;

	level1WasUpKeyDown = false;
	level1LastUpPressTime = 0;
	level1JumpCount = 0;
	level1MultiJumpActive = false;

	level1EnemyJumping = false;
	level1EnemyVelocityY = 0;

	level1EnemyBaseSpeed = 5;
	level1EnemySpeedMultiplier = 1.0f;

	level1EnemyWaitingRespawn = false;
	level1RespawnStartTime = 0;

	level1IsInvulnerable = false;
	level1InvulnerableStartTime = 0;

	level1PlayerHP = LEVEL1_PLAYER_MAX_HP;

	level1HealthPickupActive = false;
	level1HealthPickupX = 0;
	level1HealthPickupY = 0;
	level1LastHealthPickupTime = clock();
	level1HealthPickupSpawnCooldown = 6.0;

	level1ApplesCollected = 0;
	level1EnemiesKilled = 0;

	score = 0;

	resetGameOverState();
	startRunTimer();
}

// ============================================================
// DRAW
// ============================================================

void drawLevel1()
{
	iShowImage((int)level1BgX - 800, 0, 800, 700, bg2);
	iShowImage((int)level1BgX, 0, 800, 700, bg2);
	iShowImage((int)level1BgX + 800, 0, 800, 700, bg2);

	// Player
	iShowImage(level1PlayerX, level1PlayerY, 100, 100, level1PlayerImg[level1PlayerFrame]);

	// Enemy
	iShowImage(level1EnemyX, level1EnemyY, 100, 100, level1EnemyImg[level1EnemyFrame]);

	// Bullet
	if (level1IsShooting)
	{
		iSetColor(255, 255, 0);
		iFilledRectangle(level1BulletX, level1BulletY, 15, 5);
	}

	// Health pickup apple
	if (level1HealthPickupActive)
	{
		iShowImage(level1HealthPickupX, level1HealthPickupY, LEVEL1_HEALTH_PICKUP_SIZE, LEVEL1_HEALTH_PICKUP_SIZE, level1HealthPickupImg);
	}

	// Heart HP bar (top-left), same style/position as Level 3
	float level1HpRatio = level1PlayerHP / LEVEL1_PLAYER_MAX_HP;
	if (level1HpRatio < 0) level1HpRatio = 0;
	if (level1HpRatio > 1) level1HpRatio = 1;
	int level1HpFrame = (int)(level1HpRatio * 10.0f + 0.5f);
	if (level1HpFrame < 0) level1HpFrame = 0;
	if (level1HpFrame > 10) level1HpFrame = 10;
	iShowImage(15, 630, 230, 46, playerHealthBarImg[level1HpFrame]);

	// Score box
	iSetColor(65, 105, 60);
	iFilledRectangle(590, 620, 190, 50);
	iSetColor(255, 255, 255);
	char scoreBoxText[50];
	sprintf_s(scoreBoxText, "SCORE: %d", score);
	drawCenteredButtonText(590, 620, 190, 50, scoreBoxText);

	// Time bar
	double runTime = getCurrentRunTime();
	const double TIME_BAR_MAX_SECONDS = 300.0;
	int timeFill = (int)((runTime / TIME_BAR_MAX_SECONDS) * 230.0);
	if (timeFill > 230) timeFill = 230;
	if (timeFill < 0) timeFill = 0;
	iSetColor(45, 70, 45);
	iFilledRectangle(300, 620, 230, 50);
	iSetColor(120, 190, 90);
	iFilledRectangle(300, 620, timeFill, 50);
	iSetColor(255, 255, 255);
	char timeText[50], timeLabel[70];
	formatRunTime(runTime, timeText, sizeof(timeText));
	sprintf_s(timeLabel, "TIME %s", timeText);
	drawCenteredButtonText(300, 620, 230, 50, timeLabel);

	// Win-condition progress
	char progressText[64];
	sprintf_s(progressText, "Apples: %d/%d   Kills: %d/%d",
		level1ApplesCollected, LEVEL1_APPLES_REQUIRED,
		level1EnemiesKilled, LEVEL1_KILLS_REQUIRED);
	iSetColor(255, 255, 255);
	drawCenteredText(400, 590, progressText, GLUT_BITMAP_HELVETICA_18);

	if (gameOverScreenActive)
	{
		drawGameOverScreen(800, 700);
	}
}

// ============================================================
// ENEMY MOVEMENT
// ============================================================

float pickRandomLevel1EnemySpeedMultiplier()
{
	float options[6] = { 1.3f, 1.5f, 1.7f, 1.9f, 2.0f, 2.3f };
	int idx = rand() % 6;
	return options[idx];
}

void moveLevel1Enemy()
{
	if (gameOverScreenActive)
	{
		return;
	}

	// If waiting to respawn (dodged via double jump, or after hitting player), count down and skip movement
	if (level1EnemyWaitingRespawn)
	{
		double elapsed = (double)(clock() - level1RespawnStartTime) / CLOCKS_PER_SEC;
		if (elapsed >= 1.0)
		{
			level1EnemyX = 800;
			level1EnemyY = level1EnemyGroundY;
			level1EnemyWaitingRespawn = false;
			level1EnemySpeedMultiplier = pickRandomLevel1EnemySpeedMultiplier();
		}
		return;
	}

	// Move enemy left (speed randomly scaled by level1EnemySpeedMultiplier)
	level1EnemyX -= (int)(level1EnemyBaseSpeed * level1EnemySpeedMultiplier);

	// Cycle enemy walking animation frames (0 to 8)
	level1EnemyFrame = (level1EnemyFrame + 1) % 9;

	// Reset enemy position to the right side if it goes off-screen
	if (level1EnemyX < -100)
	{
		level1EnemyX = 800;
		level1EnemySpeedMultiplier = pickRandomLevel1EnemySpeedMultiplier();
	}

	// Randomly start a jump (about 5% chance each tick, only if not already jumping)
	if (!level1EnemyJumping && rand() % 100 < 5)
	{
		level1EnemyJumping = true;
		level1EnemyVelocityY = 15 * 1.5f * 1.3f;
	}

	// Apply jump physics (gravity pulls enemy back down)
	if (level1EnemyJumping)
	{
		level1EnemyY += (int)level1EnemyVelocityY;
		level1EnemyVelocityY -= 1.5f * 1.5f * 1.3f;
		if (level1EnemyY <= level1EnemyGroundY)
		{
			level1EnemyY = level1EnemyGroundY;
			level1EnemyJumping = false;
			level1EnemyVelocityY = 0;
		}
	}
}

// ============================================================
// HEALTH PICKUP (apple) - spawns at a random spot periodically;
// collecting it counts toward the win condition (10 apples + 10
// kills required, checked here and after each enemy kill).
// ============================================================

void checkLevel1WinCondition()
{
	if (level1ApplesCollected >= LEVEL1_APPLES_REQUIRED &&
		level1EnemiesKilled >= LEVEL1_KILLS_REQUIRED)
	{
		triggerGameOver(GAMEOVER_LEVEL_COMPLETE, score, 1);
		unlockLevel(2); // clearing Level 1 unlocks Level 2
	}
}

void updateLevel1HealthPickup()
{
	if (gameOverScreenActive)
	{
		return;
	}

	// Spawn a new pickup if none is active and the cooldown has elapsed.
	if (!level1HealthPickupActive)
	{
		double elapsed = (double)(clock() - level1LastHealthPickupTime) / CLOCKS_PER_SEC;
		if (elapsed >= level1HealthPickupSpawnCooldown)
		{
			level1HealthPickupActive = true;
			level1HealthPickupX = 150 + rand() % 550; // stays within the visible playfield
			level1HealthPickupY = 100 + rand() % 300; // between ground level and mid-air
		}
	}

	// Check if the player collects it.
	if (level1HealthPickupActive &&
		checkCollision(level1PlayerX, level1PlayerY, 80, 80,
			level1HealthPickupX, level1HealthPickupY, LEVEL1_HEALTH_PICKUP_SIZE, LEVEL1_HEALTH_PICKUP_SIZE))
	{
		if (level1ApplesCollected < LEVEL1_APPLES_REQUIRED)
		{
			level1ApplesCollected++;
		}

		level1HealthPickupActive = false;
		level1LastHealthPickupTime = clock();
		level1HealthPickupSpawnCooldown = 6.0 + (rand() % 500) / 100.0; // 6 - 11s until the next apple

		checkLevel1WinCondition();
	}
}

// ============================================================
// CONTINUOUS INPUT AND GAME STATE UPDATES
// ============================================================

void fixedUpdateLevel1()
{
	// Freeze all input/physics while the Game Over / Win overlay is
	// showing, so the player can't keep moving/shooting underneath it.
	if (gameOverScreenActive)
	{
		return;
	}

	// Handle Movement Inputs (supports both lowercase/uppercase and arrow keys)
	if (isKeyPressed('a') || isKeyPressed('A') || isSpecialKeyPressed(GLUT_KEY_LEFT))
	{
		level1PlayerX -= 10;
		if (level1PlayerX < 0)
		{
			level1PlayerX = 0;
		}
		level1BgX += 5; // background scrolls right when player moves left
	}
	if (isKeyPressed('d') || isKeyPressed('D') || isSpecialKeyPressed(GLUT_KEY_RIGHT))
	{
		// Keep about 1/3 of the screen visible in front of the player,
		// same idea as Level 2's PLAYER_SCREEN_LIMIT, instead of pinning
		// the player sprite at a hard edge.
		const int PLAYER_SCREEN_LIMIT = 533; // 2/3 of 800

		if (level1PlayerX < PLAYER_SCREEN_LIMIT)
		{
			level1PlayerX += 10;
			if (level1PlayerX > PLAYER_SCREEN_LIMIT)
			{
				level1PlayerX = PLAYER_SCREEN_LIMIT;
			}
			level1BgX -= 5; // background scrolls left when player moves right
		}
		else
		{
			// Once the player reaches 2/3 of the frame, keep advancing
			// the world underneath them at the same speed so they keep
			// moving forward through the level instead of getting stuck.
			level1BgX -= 10;
			level1EnemyX -= 10; // world (enemy, pickups) shifts with the scroll
			if (level1HealthPickupActive)
			{
				level1HealthPickupX -= 10;
			}
		}
	}

	// Keep level1BgX in a safe wrapping range
	if (level1BgX <= -800) level1BgX += 800;
	if (level1BgX >= 800) level1BgX -= 800;

	// --- Detect a fresh press of Up (not held down) ---
	// Supports both the Up arrow key and 'W' / 'w' as jump input.
	bool isUpKeyDownNow = (isSpecialKeyPressed(GLUT_KEY_UP) != 0) ||
		isKeyPressed('w') || isKeyPressed('W');
	if (isUpKeyDownNow && !level1WasUpKeyDown)
	{
		clock_t now = clock();
		double secondsSinceLastPress = (double)(now - level1LastUpPressTime) / CLOCKS_PER_SEC;

		if (!level1IsJumping)
		{
			// 1st jump: starts fresh from the ground
			level1IsJumping = true;
			level1PlayerVelocityY = 20;
			level1JumpCount = 1;
			level1MultiJumpActive = false;
		}
		else if (secondsSinceLastPress <= 0.35 && level1JumpCount < 3)
		{
			// 2nd or 3rd jump: must be pressed within 0.35s of the last press, max 3 total
			level1PlayerVelocityY = 20;
			level1JumpCount++;
			level1MultiJumpActive = true;
		}

		level1LastUpPressTime = now;
	}
	level1WasUpKeyDown = isUpKeyDownNow;

	// Apply jump physics (gravity pulls player back down)
	if (level1IsJumping)
	{
		level1PlayerY += (int)level1PlayerVelocityY;
		level1PlayerVelocityY -= 1.5f;

		// Don't let the player jump above the top of the screen
		if (level1PlayerY > 500)
		{
			level1PlayerY = 500;
			if (level1PlayerVelocityY > 0) level1PlayerVelocityY = 0;
		}

		if (level1PlayerY <= level1PlayerGroundY)
		{
			level1PlayerY = level1PlayerGroundY;
			level1IsJumping = false;
			level1PlayerVelocityY = 0;
			level1JumpCount = 0;
			level1MultiJumpActive = false;
		}
	}

	// Shoot Bullet (Spacebar)
	if (isKeyPressed(' '))
	{
		double timeSinceLastShot = (double)(clock() - level1LastShotTime) / CLOCKS_PER_SEC;

		if (!level1IsShooting && timeSinceLastShot >= 1.0)
		{
			level1IsShooting = true;
			level1BulletX = level1PlayerX + 55;
			level1BulletY = level1PlayerY + 25;
			level1LastShotTime = clock();
		}
	}

	// Move bullet
	if (level1IsShooting)
	{
		level1BulletX += 20;
		if (level1BulletX > 800) level1IsShooting = false;
	}

	// Check bullet hits the enemy
	if (level1IsShooting && checkCollision(level1BulletX, level1BulletY, 15, 5, level1EnemyX, level1EnemyY, 100, 100))
	{
		score++;
		if (level1EnemiesKilled < LEVEL1_KILLS_REQUIRED)
		{
			level1EnemiesKilled++;
		}
		level1EnemyX = 800; // Reset enemy
		level1IsShooting = false;

		checkLevel1WinCondition();
	}

	// Check player collision with enemy (skipped while briefly invulnerable after taking a hit)
	if (!level1IsInvulnerable && checkCollision(level1PlayerX, level1PlayerY, 80, 80, level1EnemyX, level1EnemyY, 80, 80))
	{
		// TRUE if the player is landing on top of the enemy (not just grazing past mid-air)
		bool isTopHit = (level1PlayerY >= level1EnemyY + 40);

		if (level1MultiJumpActive && !isTopHit)
		{
			// Passed through safely via 2nd/3rd jump - no damage taken
			if (!level1EnemyWaitingRespawn)
			{
				level1EnemyWaitingRespawn = true;
				level1RespawnStartTime = clock();
				level1EnemyX = -999; // hide this enemy off-screen immediately
			}
		}
		else
		{
			// Direct hit: take damage, briefly become invulnerable, enemy respawns
			level1PlayerHP -= LEVEL1_COLLISION_DAMAGE;
			if (level1PlayerHP < 0) level1PlayerHP = 0;

			level1IsInvulnerable = true;
			level1InvulnerableStartTime = clock();

			if (!level1EnemyWaitingRespawn)
			{
				level1EnemyWaitingRespawn = true;
				level1RespawnStartTime = clock();
				level1EnemyX = -999;
			}

			if (level1PlayerHP <= 0)
			{
				triggerGameOver(GAMEOVER_PLAYER_DIED, score, 1);
			}
		}
	}

	// End invulnerability window 1 second after taking a hit
	if (level1IsInvulnerable)
	{
		double elapsed = (double)(clock() - level1InvulnerableStartTime) / CLOCKS_PER_SEC;
		if (elapsed >= 1.0)
		{
			level1IsInvulnerable = false;
		}
	}
}

void updateLevel1()
{
	fixedUpdateLevel1();
	moveLevel1Enemy();
	updateLevel1HealthPickup();
}

#endif
