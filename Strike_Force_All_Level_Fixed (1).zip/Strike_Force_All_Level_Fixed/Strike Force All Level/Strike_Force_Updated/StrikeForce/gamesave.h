#ifndef GAMESAVE_H
#define GAMESAVE_H

#include <stdio.h>
#include <string.h>

const char* SAVE_FILE_NAME = "savegame.txt";
const char* HIGHSCORE_TEXT_FILE_NAME = "highscores.txt";
const int GAMESAVE_LEVEL_COUNT = 3;
const int BEST_SCORE_COUNT = 3;
const int LAST_RUN_COUNT = 2;

// BEST section: only completed levels are recorded here.
// Ranking priority: lower completion time first; if time is equal,
// higher score first.
double bestTimeByLevel[GAMESAVE_LEVEL_COUNT] = { -1.0, -1.0, -1.0 };
int highScoreByLevel[GAMESAVE_LEVEL_COUNT] = { 0, 0, 0 };
double bestTimes[GAMESAVE_LEVEL_COUNT][BEST_SCORE_COUNT];
int bestScores[GAMESAVE_LEVEL_COUNT][BEST_SCORE_COUNT];

// LAST section: every finished run is recorded here, whether the
// player won or lost. There is deliberately NO ranking in this section.
double lastTimes[GAMESAVE_LEVEL_COUNT][LAST_RUN_COUNT];
int lastScores[GAMESAVE_LEVEL_COUNT][LAST_RUN_COUNT];
int lastCountByLevel[GAMESAVE_LEVEL_COUNT] = { 0, 0, 0 };

double lastTimeByLevel[GAMESAVE_LEVEL_COUNT] = { -1.0, -1.0, -1.0 };
int lastScoreByLevel[GAMESAVE_LEVEL_COUNT] = { 0, 0, 0 };

int highestLevelUnlocked = 3;
int lastLevelPlayed = 1;
int highScore = 0;

bool isBetterRun(double newTime, int newScore, double oldTime, int oldScore)
{
	if (oldTime < 0.0) return true;
	if (newTime < oldTime - 0.0001) return true;
	if (newTime > oldTime + 0.0001) return false;
	return newScore > oldScore;
}

void recomputeOverallHighScore()
{
	highScore = 0;
	for (int i = 0; i < GAMESAVE_LEVEL_COUNT; i++)
		if (highScoreByLevel[i] > highScore) highScore = highScoreByLevel[i];
}

void sortBestScores(int levelIndex)
{
	for (int a = 0; a < BEST_SCORE_COUNT - 1; a++)
	{
		for (int b = a + 1; b < BEST_SCORE_COUNT; b++)
		{
			if (bestTimes[levelIndex][b] < 0.0) continue;
			if (bestTimes[levelIndex][a] < 0.0 ||
				isBetterRun(bestTimes[levelIndex][b], bestScores[levelIndex][b],
					bestTimes[levelIndex][a], bestScores[levelIndex][a]))
			{
				double t = bestTimes[levelIndex][a];
				bestTimes[levelIndex][a] = bestTimes[levelIndex][b];
				bestTimes[levelIndex][b] = t;
				int s = bestScores[levelIndex][a];
				bestScores[levelIndex][a] = bestScores[levelIndex][b];
				bestScores[levelIndex][b] = s;
			}
		}
	}
}

void initializeLeaderboards()
{
	for (int l = 0; l < GAMESAVE_LEVEL_COUNT; l++)
	{
		bestTimeByLevel[l] = -1.0;
		highScoreByLevel[l] = 0;
		lastTimeByLevel[l] = -1.0;
		lastScoreByLevel[l] = 0;
		lastCountByLevel[l] = 0;

		for (int r = 0; r < BEST_SCORE_COUNT; r++)
		{
			bestTimes[l][r] = -1.0;
			bestScores[l][r] = 0;
		}
		for (int r = 0; r < LAST_RUN_COUNT; r++)
		{
			lastTimes[l][r] = -1.0;
			lastScores[l][r] = 0;
		}
	}
}

void formatRunTime(double seconds, char* out, int outSize)
{
	if (seconds < 0.0)
	{
		sprintf_s(out, outSize, "--:--");
		return;
	}
	int total = (int)(seconds + 0.5);
	int minutes = total / 60;
	int secs = total % 60;
	sprintf_s(out, outSize, "%02d:%02d", minutes, secs);
}

void writeHighScoreTextFile()
{
	FILE* file = NULL;
	fopen_s(&file, HIGHSCORE_TEXT_FILE_NAME, "w");
	if (file == NULL) return;

	fprintf(file, "STRIKE FORCE - HIGH SCORES\n");
	fprintf(file, "BEST = completed levels only; lower time first, then higher score.\n");
	fprintf(file, "LAST = last two completed/failed runs, shown newest first; no ranking.\n\n");

	for (int l = 0; l < GAMESAVE_LEVEL_COUNT; l++)
	{
		fprintf(file, "LEVEL %d\n", l + 1);
		fprintf(file, "BEST\n");
		fprintf(file, "Rank Time Score\n");
		for (int r = 0; r < BEST_SCORE_COUNT; r++)
		{
			if (bestTimes[l][r] < 0.0) continue;
			char t[16];
			formatRunTime(bestTimes[l][r], t, sizeof(t));
			fprintf(file, "%d %s %d\n", r + 1, t, bestScores[l][r]);
		}
		fprintf(file, "LAST\n");
		fprintf(file, "Time Score\n");
		for (int r = 0; r < LAST_RUN_COUNT; r++)
		{
			if (lastTimes[l][r] < 0.0) continue;
			char t[16];
			formatRunTime(lastTimes[l][r], t, sizeof(t));
			fprintf(file, "%s %d\n", t, lastScores[l][r]);
		}
		fprintf(file, "\n");
	}
	fclose(file);
}

void saveGameData()
{
	FILE* file = NULL;
	fopen_s(&file, SAVE_FILE_NAME, "w");
	if (file == NULL) return;

	// Version marker prevents the old 5-entry leaderboard format from
	// being interpreted as the new BEST/LAST structure.
	fprintf(file, "STRIKE_FORCE_SAVE_V2\n");
	fprintf(file, "%d\n%d\n", highestLevelUnlocked, lastLevelPlayed);

	for (int l = 0; l < GAMESAVE_LEVEL_COUNT; l++)
	{
		for (int r = 0; r < BEST_SCORE_COUNT; r++)
			fprintf(file, "%.3f %d\n", bestTimes[l][r], bestScores[l][r]);
		for (int r = 0; r < LAST_RUN_COUNT; r++)
			fprintf(file, "%.3f %d\n", lastTimes[l][r], lastScores[l][r]);
	}
	fclose(file);
	writeHighScoreTextFile();
}

void loadGameData()
{
	initializeLeaderboards();

	FILE* file = NULL;
	fopen_s(&file, SAVE_FILE_NAME, "r");
	if (file == NULL)
	{
		highestLevelUnlocked = 3;
		lastLevelPlayed = 1;
		recomputeOverallHighScore();
		saveGameData();
		return;
	}

	char header[64];
	bool valid = (fscanf_s(file, "%63s", header, (unsigned)_countof(header)) == 1);
	if (!valid || strcmp(header, "STRIKE_FORCE_SAVE_V2") != 0)
	{
		fclose(file);
		// The old format cannot tell us whether its entries were wins or
		// losses, so it is intentionally discarded rather than falsely
		// placing failed runs in the new BEST section.
		initializeLeaderboards();
		saveGameData();
		return;
	}

	if (fscanf_s(file, "%d", &highestLevelUnlocked) != 1) highestLevelUnlocked = 3;
	if (fscanf_s(file, "%d", &lastLevelPlayed) != 1) lastLevelPlayed = 1;

	for (int l = 0; l < GAMESAVE_LEVEL_COUNT; l++)
	{
		for (int r = 0; r < BEST_SCORE_COUNT; r++)
			fscanf_s(file, "%lf %d", &bestTimes[l][r], &bestScores[l][r]);
		for (int r = 0; r < LAST_RUN_COUNT; r++)
			fscanf_s(file, "%lf %d", &lastTimes[l][r], &lastScores[l][r]);
	}
	fclose(file);

	for (int l = 0; l < GAMESAVE_LEVEL_COUNT; l++)
	{
		sortBestScores(l);
		if (bestTimes[l][0] >= 0.0)
		{
			bestTimeByLevel[l] = bestTimes[l][0];
			highScoreByLevel[l] = bestScores[l][0];
		}
		lastCountByLevel[l] = 0;
		for (int r = 0; r < LAST_RUN_COUNT; r++)
			if (lastTimes[l][r] >= 0.0) lastCountByLevel[l]++;
		if (lastCountByLevel[l] > 0)
		{
			lastTimeByLevel[l] = lastTimes[l][0];
			lastScoreByLevel[l] = lastScores[l][0];
		}
	}

	if (highestLevelUnlocked < 3) highestLevelUnlocked = 3;
	if (highestLevelUnlocked > 3) highestLevelUnlocked = 3;
	recomputeOverallHighScore();
	writeHighScoreTextFile();
}

// Record a run in the LAST section. Newest run is always LAST[0].
void recordLastRun(int levelNumber, int finalScore, double finalTime)
{
	int index = levelNumber - 1;
	if (index < 0 || index >= GAMESAVE_LEVEL_COUNT) return;

	for (int r = LAST_RUN_COUNT - 1; r > 0; r--)
	{
		lastTimes[index][r] = lastTimes[index][r - 1];
		lastScores[index][r] = lastScores[index][r - 1];
	}
	lastTimes[index][0] = finalTime;
	lastScores[index][0] = finalScore;
	lastCountByLevel[index] = LAST_RUN_COUNT;
	lastTimeByLevel[index] = finalTime;
	lastScoreByLevel[index] = finalScore;
}

// Record a run in BEST only when the player actually completed the level.
void recordCompletedLevel(int levelNumber, int finalScore, double finalTime)
{
	int index = levelNumber - 1;
	if (index < 0 || index >= GAMESAVE_LEVEL_COUNT) return;

	for (int r = 0; r < BEST_SCORE_COUNT; r++)
	{
		if (isBetterRun(finalTime, finalScore, bestTimes[index][r], bestScores[index][r]))
		{
			for (int k = BEST_SCORE_COUNT - 1; k > r; k--)
			{
				bestTimes[index][k] = bestTimes[index][k - 1];
				bestScores[index][k] = bestScores[index][k - 1];
			}
			bestTimes[index][r] = finalTime;
			bestScores[index][r] = finalScore;
			break;
		}
	}

	sortBestScores(index);
	bestTimeByLevel[index] = bestTimes[index][0];
	highScoreByLevel[index] = bestScores[index][0];
}

// Called once when a run ends. Every run goes to LAST; only a win goes to BEST.
void updateHighScoreIfNeeded(int levelNumber, int finalScore, double finalTime, bool completed)
{
	recordLastRun(levelNumber, finalScore, finalTime);
	if (completed)
		recordCompletedLevel(levelNumber, finalScore, finalTime);

	recomputeOverallHighScore();
	saveGameData();
}

void unlockLevel(int levelNumber)
{
	if (levelNumber > highestLevelUnlocked) highestLevelUnlocked = levelNumber;
	saveGameData();
}

void rememberLastLevel(int levelNumber)
{
	lastLevelPlayed = levelNumber;
	saveGameData();
}

#endif
