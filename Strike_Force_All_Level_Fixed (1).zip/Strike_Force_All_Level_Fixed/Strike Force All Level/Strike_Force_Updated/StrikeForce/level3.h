#ifndef LEVEL3_H
#define LEVEL3_H

#include <time.h>
#include <stdio.h>
#include <stdlib.h>

#include "player.h"
#include "enemy.h"
#include "score.h"

// ============================================================
// LEVEL 3 - SKY STRIKE
// A side-scrolling plane shooter: the player's red biplane
// flies over a parallax sky of clouds and floating islands,
// shooting down green enemy planes. Matches the reference
// layout: heart HP bar top-left, plain "Score: X" text
// top-center, EXIT button top-right, floating islands and
// clouds scrolling underneath.
// ============================================================

// ------------------------------------------------------------
// External variables/functions coming from iMain.cpp
// ------------------------------------------------------------

extern int gameState;
extern int score;

// ============================================================
// LEVEL 3 CONSTANTS
// ============================================================

const int LEVEL3_SCREEN_WIDTH = 800;
const int LEVEL3_SCREEN_HEIGHT = 700;

const int LEVEL3_MAX_ACTIVE_ENEMIES = 3;

const float LEVEL3_ENEMY_GUNFIRE_DAMAGE = 8.0f;   // damage from an enemy's bullet hitting the player
const float LEVEL3_ENEMY_COLLISION_DAMAGE = 35.0f; // damage from directly colliding with an enemy (heavy, but not instant death)
const float LEVEL3_PLAYER_BULLET_DAMAGE = 10.0f;  // damage a player bullet does to an enemy
const int LEVEL3_BULLET_SPEED = 22;
const int LEVEL3_SCORE_PER_KILL = 10;

// ------------------------------------------------------------
// WIN CONDITION - collect 20 coins AND kill 15 enemies, same
// pattern as Level 1's apples + kills requirement.
// ------------------------------------------------------------

const int LEVEL3_COINS_REQUIRED = 20;
const int LEVEL3_KILLS_REQUIRED = 15;
int level3CoinsCollected = 0;
int level3EnemiesKilled = 0;

// ------------------------------------------------------------
// PICKUPS - a coin (counts toward the win condition) and an
// orange health pickup (heals HP) spawn at random screen
// positions, similar to Level 1's apple.
// ------------------------------------------------------------

int level3CoinImg = 0;
bool level3CoinActive = false;
int level3CoinX = 0, level3CoinY = 0;
const int LEVEL3_COIN_SIZE = 40;
clock_t level3LastCoinTime = 0;
double level3CoinSpawnCooldown = 4.0; // seconds between coins, randomized each spawn

int level3HealthPickupImg = 0;
bool level3HealthPickupActive = false;
int level3HealthPickupX = 0, level3HealthPickupY = 0;
const int LEVEL3_HEALTH_PICKUP_SIZE = 45;
const float LEVEL3_HEALTH_PICKUP_HEAL = 20.0f;
clock_t level3LastHealthPickupTime = 0;
double level3HealthPickupSpawnCooldown = 8.0; // seconds between health pickups, randomized each spawn

// ============================================================
// LEVEL 3 IMAGE VARIABLES (parallax background layers)
// ============================================================

int level3BgSky;          // solid sky color layer (back-most)
int level3BgClouds;       // clouds + tree line
int level3BgFarIslands;   // far floating islands
int level3BgNearIslands;  // near floating islands + ground

// ============================================================
// LEVEL 3 STATE
// ============================================================

int level3KillCount = 0;
clock_t level3RunStartTime = 0;

// Parallax scroll offsets - each layer scrolls at a different
// speed to create a sense of depth, exactly like the reference
// screenshot's stacked sky / clouds / islands.
float level3SkyScrollX = 0;
float level3CloudScrollX = 0;
float level3FarIslandScrollX = 0;
float level3NearIslandScrollX = 0;

const float LEVEL3_SKY_SCROLL_SPEED = 0.0f;     // sky is static (just a color wash)
const float LEVEL3_CLOUD_SCROLL_SPEED = 0.6f;
const float LEVEL3_FAR_ISLAND_SCROLL_SPEED = 1.4f;
const float LEVEL3_NEAR_ISLAND_SCROLL_SPEED = 2.6f;

// ============================================================
// LOAD IMAGES
// ============================================================

void loadLevel3Images()
{
	level3BgSky = iLoadImage("L3_bg_sky.png");
	level3BgClouds = iLoadImage("L3_bg_clouds.png");
	level3BgFarIslands = iLoadImage("L3_bg_farislands.png");
	level3BgNearIslands = iLoadImage("L3_bg_nearislands.png");

	loadPlayerImages();
	loadEnemyImages();

	level3CoinImg = iLoadImage("L3_coin.png");
	level3HealthPickupImg = iLoadImage("L3_health_orange.png");
}

// ============================================================
// RESET
// ============================================================

void resetLevel3()
{
	resetPlayer();
	resetEnemies();
	resetScore();

	level3KillCount = 0;

	level3SkyScrollX = 0;
	level3CloudScrollX = 0;
	level3FarIslandScrollX = 0;
	level3NearIslandScrollX = 0;

	level3CoinsCollected = 0;
	level3EnemiesKilled = 0;

	level3CoinActive = false;
	level3CoinX = 0;
	level3CoinY = 0;
	level3LastCoinTime = clock();
	level3CoinSpawnCooldown = 4.0;

	level3HealthPickupActive = false;
	level3HealthPickupX = 0;
	level3HealthPickupY = 0;
	level3LastHealthPickupTime = clock();
	level3HealthPickupSpawnCooldown = 8.0;

	gameOverScreenActive = false;
	resetGameOverState();
	startRunTimer();
	level3RunStartTime = currentRunStartTime;
}

// ============================================================
// DRAW - PARALLAX BACKGROUND
// ============================================================

// Draws one scrolling layer twice, side by side, so it wraps
// seamlessly forever as scrollX increases.
void drawLevel3ParallaxLayer(int image, float scrollX)
{
	int wrapped = ((int)scrollX) % LEVEL3_SCREEN_WIDTH;
	if (wrapped > 0)
	{
		wrapped -= LEVEL3_SCREEN_WIDTH;
	}

	iShowImage(wrapped, 0, LEVEL3_SCREEN_WIDTH, LEVEL3_SCREEN_HEIGHT, image);
	iShowImage(wrapped + LEVEL3_SCREEN_WIDTH, 0, LEVEL3_SCREEN_WIDTH, LEVEL3_SCREEN_HEIGHT, image);
}

void drawLevel3Background()
{
	drawLevel3ParallaxLayer(level3BgSky, level3SkyScrollX);
	drawLevel3ParallaxLayer(level3BgClouds, level3CloudScrollX);
	drawLevel3ParallaxLayer(level3BgFarIslands, level3FarIslandScrollX);
	drawLevel3ParallaxLayer(level3BgNearIslands, level3NearIslandScrollX);
}

// ============================================================
// DRAW - FULL LEVEL
// ============================================================

void drawLevel3()
{
	drawLevel3Background();

	drawEnemies();
	drawPlayer();

	// Coin pickup
	if (level3CoinActive)
	{
		iShowImage(level3CoinX, level3CoinY, LEVEL3_COIN_SIZE, LEVEL3_COIN_SIZE, level3CoinImg);
	}

	// Orange health pickup
	if (level3HealthPickupActive)
	{
		iShowImage(level3HealthPickupX, level3HealthPickupY, LEVEL3_HEALTH_PICKUP_SIZE, LEVEL3_HEALTH_PICKUP_SIZE, level3HealthPickupImg);
	}

	// HUD: heart HP bar
	drawPlayerHUD();

	// Score box
	iSetColor(70, 45, 105);
	iFilledRectangle(590, 620, 190, 50);
	iSetColor(255, 255, 255);
	char scoreBoxText[50];
	sprintf_s(scoreBoxText, "SCORE: %d", score);
	drawCenteredButtonText(590, 620, 190, 50, scoreBoxText);

	// Time bar
	double runTime = getCurrentRunTime();
	const double TIME_BAR_MAX_SECONDS = 300.0;
	int timeFill = (int)((runTime / TIME_BAR_MAX_SECONDS) * 230.0);
	if (timeFill > 230) timeFill = 230;
	if (timeFill < 0) timeFill = 0;
	iSetColor(55, 45, 80);
	iFilledRectangle(300, 620, 230, 50);
	iSetColor(145, 110, 210);
	iFilledRectangle(300, 620, timeFill, 50);
	iSetColor(255, 255, 255);
	char timeText[50], timeLabel[70];
	formatRunTime(runTime, timeText, sizeof(timeText));
	sprintf_s(timeLabel, "TIME %s", timeText);
	drawCenteredButtonText(300, 620, 230, 50, timeLabel);

	// Win-condition progress
	char progressText[64];
	sprintf_s(progressText, "Coins: %d/%d   Kills: %d/%d",
		level3CoinsCollected, LEVEL3_COINS_REQUIRED,
		level3EnemiesKilled, LEVEL3_KILLS_REQUIRED);
	iSetColor(255, 255, 255);
	drawCenteredText(400, 590, progressText, GLUT_BITMAP_HELVETICA_18);

	if (gameOverScreenActive)
	{
		drawGameOverScreen(LEVEL3_SCREEN_WIDTH, LEVEL3_SCREEN_HEIGHT);
	}
}

// ============================================================
// UPDATE - INPUT / MOVEMENT
// ============================================================

void handleLevel3Input()
{
	if (isKeyPressed('w') || isKeyPressed('W') || isSpecialKeyPressed(GLUT_KEY_UP))
	{
		movePlayerUp();
	}
	if (isKeyPressed('s') || isKeyPressed('S') || isSpecialKeyPressed(GLUT_KEY_DOWN))
	{
		movePlayerDown();
	}
	if (isKeyPressed('d') || isKeyPressed('D') || isSpecialKeyPressed(GLUT_KEY_RIGHT))
	{
		// Let the plane fly all the way to the right edge of the
		// screen (movePlayerForward already clamps at screenWidth).
		// Enemies and pickups are screen-space entities with no
		// world camera, so pinning the plane partway and scrolling
		// the background instead just desyncs it from them - the
		// plane should simply be free to reach the edge.
		movePlayerForward(LEVEL3_SCREEN_WIDTH);
	}
	if (isKeyPressed('a') || isKeyPressed('A') || isSpecialKeyPressed(GLUT_KEY_LEFT))
	{
		movePlayerBackward();
	}

	if (isKeyPressed(' '))
	{
		if (playerTryShoot())
		{
			// NOTE: Audios/shoot.mp3 is not included in this project's
			// Audios folder yet. Add a short shoot sound file with this
			// exact name to enable it - playSoundEffect() silently does
			// nothing if the file is missing, so this call is safe either way.
			playSoundEffect("Audios/shoot.mp3");
		}
	}
}

void updateLevel3Background()
{
	level3SkyScrollX -= LEVEL3_SKY_SCROLL_SPEED;
	level3CloudScrollX -= LEVEL3_CLOUD_SCROLL_SPEED;
	level3FarIslandScrollX -= LEVEL3_FAR_ISLAND_SCROLL_SPEED;
	level3NearIslandScrollX -= LEVEL3_NEAR_ISLAND_SCROLL_SPEED;
}

// ============================================================
// UPDATE - COLLISIONS
// ============================================================

void checkLevel3WinCondition()
{
	if (level3CoinsCollected >= LEVEL3_COINS_REQUIRED &&
		level3EnemiesKilled >= LEVEL3_KILLS_REQUIRED)
	{
		triggerGameOver(GAMEOVER_LEVEL_COMPLETE, score, 3);
		unlockLevel(3); // clearing level 3 keeps it unlocked (already max, but harmless)
	}
}

// Spawns / handles collection of the coin and orange health
// pickups, at random positions within the visible screen.
void updateLevel3Pickups()
{
	if (gameOverScreenActive)
	{
		return;
	}

	// --- Coin ---
	if (!level3CoinActive)
	{
		double elapsed = (double)(clock() - level3LastCoinTime) / CLOCKS_PER_SEC;
		if (elapsed >= level3CoinSpawnCooldown)
		{
			level3CoinActive = true;
			level3CoinX = 100 + rand() % 600;
			level3CoinY = 100 + rand() % 450;
		}
	}

	if (level3CoinActive &&
		checkCollision((int)player.x, (int)player.y, player.width, player.height,
			level3CoinX, level3CoinY, LEVEL3_COIN_SIZE, LEVEL3_COIN_SIZE))
	{
		if (level3CoinsCollected < LEVEL3_COINS_REQUIRED)
		{
			level3CoinsCollected++;
		}

		level3CoinActive = false;
		level3LastCoinTime = clock();
		level3CoinSpawnCooldown = 3.0 + (rand() % 300) / 100.0; // 3 - 6s until the next coin

		checkLevel3WinCondition();
	}

	// --- Orange health pickup ---
	if (!level3HealthPickupActive)
	{
		double elapsed = (double)(clock() - level3LastHealthPickupTime) / CLOCKS_PER_SEC;
		if (elapsed >= level3HealthPickupSpawnCooldown)
		{
			level3HealthPickupActive = true;
			level3HealthPickupX = 100 + rand() % 600;
			level3HealthPickupY = 100 + rand() % 450;
		}
	}

	if (level3HealthPickupActive &&
		checkCollision((int)player.x, (int)player.y, player.width, player.height,
			level3HealthPickupX, level3HealthPickupY, LEVEL3_HEALTH_PICKUP_SIZE, LEVEL3_HEALTH_PICKUP_SIZE))
	{
		healPlayer(LEVEL3_HEALTH_PICKUP_HEAL);

		level3HealthPickupActive = false;
		level3LastHealthPickupTime = clock();
		level3HealthPickupSpawnCooldown = 7.0 + (rand() % 500) / 100.0; // 7 - 12s until the next one
	}
}

void handleLevel3Collisions()
{
	// Player bullet vs enemies
	if (player.isShooting)
	{
		for (int i = 0; i < ENEMY_MAX_SLOTS; i++)
		{
			if (!enemies[i].alive)
			{
				continue;
			}

			bool hit = checkCollisionF(
				player.bulletX, player.bulletY, 40, 16,
				enemies[i].x, enemies[i].y, (float)ENEMY_WIDTH, (float)ENEMY_HEIGHT
			);

			if (hit)
			{
				player.isShooting = false;

				bool killed = damageEnemy(i, LEVEL3_PLAYER_BULLET_DAMAGE);
				if (killed)
				{
					level3KillCount++;
					if (level3EnemiesKilled < LEVEL3_KILLS_REQUIRED)
					{
						level3EnemiesKilled++;
					}
					addScore(LEVEL3_SCORE_PER_KILL);
					playSoundEffect("Audios/explosion.mp3"); // add this file to Audios/ to enable; safe no-op if missing

					checkLevel3WinCondition();
				}
				break;
			}
		}
	}

	// Enemy vs player collision - now deals heavy damage instead of an
	// instant kill, consistent with Level 1's enemy-contact damage.
	// The colliding enemy is still destroyed on impact.
	for (int i = 0; i < ENEMY_MAX_SLOTS; i++)
	{
		if (!enemies[i].alive)
		{
			continue;
		}

		bool hit = checkCollisionF(
			player.x, player.y, (float)player.width, (float)player.height,
			enemies[i].x, enemies[i].y, (float)ENEMY_WIDTH, (float)ENEMY_HEIGHT
		);

		if (hit)
		{
			damageEnemy(i, ENEMY_MAX_HP); // destroy the colliding enemy outright
			damagePlayer(LEVEL3_ENEMY_COLLISION_DAMAGE); // heavy damage, but respects invulnerability
			playSoundEffect("Audios/explosion.mp3"); // add this file to Audios/ to enable; safe no-op if missing
		}
	}

	// Enemy gunfire vs player
	for (int i = 0; i < ENEMY_MAX_SLOTS; i++)
	{
		if (!enemies[i].alive || !enemies[i].isShooting)
		{
			continue;
		}

		bool hit = checkCollisionF(
			enemies[i].bulletX, enemies[i].bulletY, (float)ENEMY_BULLET_WIDTH, (float)ENEMY_BULLET_HEIGHT,
			player.x, player.y, (float)player.width, (float)player.height
		);

		if (hit)
		{
			enemies[i].isShooting = false; // bullet is consumed on hit
			damagePlayer(LEVEL3_ENEMY_GUNFIRE_DAMAGE);
			playSoundEffect("Audios/explosion.mp3"); // add this file to Audios/ to enable; safe no-op if missing
		}
	}
}

// ============================================================
// UPDATE - MAIN ENTRY POINT
// ============================================================

void updateLevel3()
{
	if (gameOverScreenActive)
	{
		return;
	}

	handleLevel3Input();

	updatePlayerAnimation();
	updatePlayerBullet(LEVEL3_BULLET_SPEED, LEVEL3_SCREEN_WIDTH);
	updatePlayerInvulnerability();

	updateLevel3Background();

	spawnEnemies(LEVEL3_SCREEN_WIDTH, LEVEL3_MAX_ACTIVE_ENEMIES);
	updateEnemies();

	handleLevel3Collisions();
	updateLevel3Pickups();

	// Lose condition
	if (!player.alive)
	{
		triggerGameOver(GAMEOVER_PLAYER_DIED, score, 3);
	}
}

#endif
